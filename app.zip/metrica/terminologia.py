"""
Terminologia metrica usata dal programma, con le definizioni (per l'uso didattico) e i nomi dei metri.

Qui sta anche ogni scelta di convenzione: dove i manuali non sono concordi, il programma dichiara
il criterio che adotta (voci «Criterio»).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Voce:
    termine: str
    definizione: str


@dataclass(frozen=True)
class Sezione:
    titolo: str
    voci: tuple[Voce, ...]


GLOSSARIO: tuple[Sezione, ...] = (
    Sezione("La parola", (
        Voce("accento tonico", "La maggiore intensità con cui si pronuncia una sillaba della parola: è l'accento di parola, "
             "indipendente dal verso (amóre, càpitano, virtù)."),
        Voce("sillaba tonica / atona", "Tonica è la sillaba che porta l'accento tonico; le altre sono atone. Una parola "
             "è tronca, piana, sdrucciola, bisdrucciola... secondo che la tonica sia l'ultima, la penultima, la terzultima, la quartultima..."),
        Voce("accento grafico", "Il segno scritto sulla vocale (à, è, é, ì, ò, ó, ù). In italiano è obbligatorio sulle parole tronche "
             "polisillabe e su alcuni monosillabi (è, più, ciò); qui lo scrivi tu quando serve a togliere un'ambiguità (àncora / ancòra, compùter) o a segnare la dieresi."),
        Voce("parola atona (clitica)", "Parola che si appoggia a quella vicina e non porta ictus da sola: articoli, preposizioni, "
             "congiunzioni e pronomi atoni (il, di, e, che, mi, ti, si...)."),
        Voce("sillaba grammaticale", "La sillaba della parola isolata, secondo le regole di divisione (ca-pi-ta-no)."),
        Voce("dittongo, trittongo, iato", "Dittongo: due vocali nella stessa sillaba, di cui una è i o u atona (pie-no, quan-do). "
             "Trittongo: tre vocali nella stessa sillaba (suoi, miei). Iato: due vocali vicine in sillabe diverse (po-e-ta, pa-ù-ra)."),
    )),
    Sezione("Gli incontri di vocali", (
        Voce("sinalefe", "La vocale finale di una parola e quella iniziale della successiva formano una sola sillaba metrica "
             "(co-me‿il = 2 sillabe invece di 3). È la lettura normale, salvo che la tradizione o il senso impongano la dialefe."),
        Voce("dialefe", "Le due vocali restano in sillabe separate: la sillaba in più va contata."),
        Voce("dieresi", "Un dittongo si legge come iato (vi-a invece di via); si segna con ï, ë, ö, ü: visïone, avëa."),
        Voce("sineresi", "Due vocali in iato si leggono come dittongo (poe-ta invece di po-e-ta)."),
        Voce("elisione", "Caduta della vocale finale davanti a vocale, segnata con l'apostrofo (l'amore, dell'altra): è un fatto "
             "della scrittura, diversa dalla sinalefe, che riguarda solo la lettura del verso."),
        Voce("troncamento e apocope", "Caduta di una vocale o di una sillaba finale: cammin, amor, po', de' (= dei). Le parole che "
             "restano senza vocale ('l, 'n) si appoggiano alla parola precedente (e'l, che'n)."),
    )),
    Sezione("Il verso", (
        Voce("sede", "La posizione di una sillaba metrica nel verso: 1ª, 2ª, 3ª... Si contano dopo sinalefi, dieresi e sineresi."),
        Voce("ictus", "La sillaba su cui cade l'accento ritmico del verso. Il programma distingue gli ictus principali, "
             "cioè le sedi cardine del metro (per l'endecasillabo la 10ª, obbligatoria, e la 6ª o la 4ª), dalle altre sillabe toniche "
             "che cadono in sedi diverse (per esempio 2ª, 7ª, 8ª). L'ultimo accento del verso è sempre un ictus."),
        Voce("ictus contigui", "Due sillabe toniche in sedi vicine (4ª e 5ª, per esempio): l'«urto d'accenti», che rende il ritmo più "
             "spezzato."),
        Voce("legge dell'ultimo accento (conteggio metrico)", "Il nome del verso dipende dalla posizione dell'ultimo ictus: si contano le "
             "sillabe fino all'ultimo ictus e se ne aggiunge una. Un verso tronco di 10 sillabe, un piano di 11 e uno sdrucciolo di 12 "
             "contano tutti 11 e sono endecasillabi."),
        Voce("chiusura", "Come finisce il verso dopo l'ultimo ictus: tronca (0 sillabe dopo), piana (1), sdrucciola (2), bisdrucciola (3), "
             "trisdrucciola (4), quadrisdrucciola (5), quintisdrucciola (6)."),
        Voce("misura", "Il nome del verso dal conteggio metrico: quaternario (4), quinario (5), senario (6), settenario (7), ottonario (8), "
             "novenario (9), decasillabo (10), endecasillabo (11), dodecasillabo (12)."),
    )),
    Sezione("L'endecasillabo", (
        Voce("endecasillabo", "Verso con l'ultimo ictus in 10ª sede (le sillabe fisiche possono essere 10, 11, 12 o più)."),
        Voce("a maiore", "Endecasillabo con ictus in 6ª sede (oltre alla 10ª): il verso si divide idealmente in 6+5."),
        Voce("a minore", "Endecasillabo con ictus in 4ª sede ma non in 6ª (oltre alla 10ª): si divide idealmente in 4+7."),
        Voce("non canonico", "Endecasillabo con ictus in 10ª ma senza ictus né in 4ª né in 6ª."),
        Voce("Criterio adottato", "Se la 6ª è tonica il verso è «a maiore», anche quando lo è pure la 4ª; se la 6ª non è tonica "
             "ma lo è la 4ª è «a minore». Alcuni manuali trattano a parte i versi con la 4ª e la 6ª insieme: il programma lo segnala "
             "nella spiegazione. Le sillabe toniche in altre sedi sono indicate come «altre sillabe toniche», senza giudizio."),
    )),
)

_NOMI_METRO = {
    4: "quaternario", 5: "quinario", 6: "senario", 7: "settenario", 8: "ottonario", 9: "novenario",
    10: "decasillabo", 11: "endecasillabo", 12: "dodecasillabo",
}


def nome_metro(conteggio_metrico: int | None) -> str | None:
    """Il nome tradizionale del verso di quel conteggio metrico (None se non ne ha uno comune)."""
    return _NOMI_METRO.get(conteggio_metrico) if conteggio_metrico else None


def chiusura_aggettivo(chiusura: str) -> str:
    """tronco -> tronca, sdrucciolo -> sdrucciola: «chiusura» è femminile."""
    return chiusura[:-1] + "a" if chiusura.endswith("o") else chiusura


def misura_del(nome: str) -> str:
    """«del settenario», «dell'ottonario»."""
    return ("dell'" if nome[0] in "aeiou" else "del ") + nome


def glossario_testo(larghezza: int = 88) -> str:
    """Il glossario come testo semplice, per il terminale."""
    import textwrap
    righe: list[str] = []
    for sezione in GLOSSARIO:
        righe += ["", sezione.titolo.upper()]
        for voce in sezione.voci:
            righe += textwrap.wrap(f"{voce.termine}: {voce.definizione}", larghezza,
                                   initial_indent="  ", subsequent_indent="      ")
    return "\n".join(righe).strip("\n")
