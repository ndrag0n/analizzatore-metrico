"""Il lessico delle eccezioni: lettura dei file JSON e forme derivate."""
from __future__ import annotations

import json
import warnings
from functools import lru_cache
from pathlib import Path

from .testo import _ACCENTED_VOWELS, _STRIP_ACCENTS


def _read_dictionary(path: Path) -> dict[str, str] | None:
    """Legge un JSON parola -> parola accentata; None (con avviso) se manca o è malformato."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        warnings.warn(f"file {path} non trovato. Eccezioni disabilitate.", stacklevel=3)
        return None
    except (json.JSONDecodeError, UnicodeDecodeError, OSError) as error:
        warnings.warn(f"impossibile leggere {path} ({error}). Eccezioni disabilitate.", stacklevel=3)
        return None
    if not isinstance(data, dict):
        warnings.warn(f"{path} deve contenere un dizionario. Eccezioni disabilitate.", stacklevel=3)
        return None
    return {k: v for k, v in data.items() if isinstance(k, str) and isinstance(v, str)}


_EXTRA_FILES = ("sdrucciole_extra.json", "iati.json", "curiosita.json", "apocopi.json")


def load_exceptions(filepath: str | Path | None = None) -> dict[str, str]:
    """
    Carica il dizionario delle eccezioni (parola -> parola accentata).

    Con un percorso legge solo quel file. Senza argomenti legge "exceptions.json" accanto a
    questo file, qualunque sia la cartella di lavoro, e vi aggiunge (senza sovrascriverle)
    le voci dei file opzionali "sdrucciole_extra.json" (verbi, nomi e aggettivi sdruccioli)
    "iati.json" (parole con i/u tonica in iato: polizìa, paùra) e "curiosita.json" (parole
    giocose e rarissime, come le rime sdrucciolissime di Boito) e "apocopi.json" (forme
    troncate che mantengono l'accento sulla radice: èsser, pòsson, richiùdon) se esistono.
    Se il file principale manca, è illeggibile o malformato restituisce un dizionario vuoto
    avvisando l'utente; le voci non valide (chiave o valore non stringa) vengono scartate.
    """
    if filepath is not None:
        return _read_dictionary(Path(filepath)) or {}
    folder = Path(__file__).resolve().parent.parent      # accanto alla cartella metrica/
    data = _read_dictionary(folder / "exceptions.json")
    if data is None:
        return {}
    for name in _EXTRA_FILES:
        extra = folder / name
        if extra.exists():
            for word, accented in (_read_dictionary(extra) or {}).items():
                data.setdefault(word, accented)
    return data


@lru_cache(maxsize=1)
def _default_lexicon() -> dict[str, str]:
    """Lessico predefinito, letto dai file una sola volta per processo (non va modificato)."""
    return load_exceptions()


class _LexiconIndex:
    """
    Forme accentate che si possono ricavare dal lessico delle eccezioni, calcolate
    una volta sola per ogni dizionario:
      - il plurale dei nomi (anima -> anime, abito -> abiti, principe -> principi);
      - la terza persona plurale dei verbi con infinito sdrucciolo (mèttere -> mèttono, mèttano).
    """

    def __init__(self, exceptions: dict[str, str]):
        self.source = exceptions          # riferimento tenuto vivo: serve a riconoscere il dizionario
        self.size = len(exceptions)
        self.derived: dict[str, str] = {}

        for word, accented in exceptions.items():
            # Ignora le voci malformate (senza accento o che non corrispondono alla chiave)
            if (
                sum(1 for ch in accented if ch in _ACCENTED_VOWELS) != 1
                or accented.translate(_STRIP_ACCENTS) != word
            ):
                continue
            pos = next(i for i, ch in enumerate(accented) if ch in _ACCENTED_VOWELS)

            # Si usa la prima desinenza che corrisponde: l'ordine va dalla più specifica alla più generica
            for tail, replacements in _INFLECTIONS:
                if not word.endswith(tail):
                    continue
                if len(word) - len(tail) > pos:          # la sillaba tonica deve restare nella radice
                    for new_tail in replacements:
                        new_word = word[: len(word) - len(tail)] + new_tail
                        new_accented = accented[: len(accented) - len(tail)] + new_tail
                        if new_word not in exceptions:
                            self.derived.setdefault(new_word, new_accented)
                break


# (desinenza, desinenze derivate): il numero cambia, la sillaba tonica no.
# Le forme in più (es. "ci" e "chi") sono innocue: se non esistono, non vengono mai cercate.
# Un infinito in -ere non forma il plurale in -i (leggero/leggeri è piano), per questo viene prima di "e".
_INFLECTIONS = (
    ("ere", ("ono", "ano")),     # mèttere -> mèttono, mèttano
    ("co", ("ci", "chi")),       # tècnico -> tècnici
    ("go", ("gi", "ghi")),       # catàlogo -> catàloghi
    ("ca", ("ce", "che")),       # amèrica -> amèrice (innocua), àbaca -> àbache
    ("ga", ("ge", "ghe")),
    ("io", ("i",)),              # ìncendio -> ìncendi
    ("o", ("i",)),               # àlbero -> àlberi
    ("a", ("e",)),               # ànima -> ànime
    ("e", ("i",)),               # prìncipe -> prìncipi
)

_LEXICON_INDEXES: dict[int, _LexiconIndex] = {}
_MAX_CACHED_INDEXES = 4


def _get_lexicon_index(exceptions: dict[str, str]) -> _LexiconIndex:
    """Restituisce l'indice del dizionario, ricalcolandolo solo se il dizionario è cambiato."""
    index = _LEXICON_INDEXES.get(id(exceptions))
    if index is None or index.source is not exceptions or index.size != len(exceptions):
        if len(_LEXICON_INDEXES) >= _MAX_CACHED_INDEXES:
            _LEXICON_INDEXES.pop(next(iter(_LEXICON_INDEXES)))
        index = _LEXICON_INDEXES[id(exceptions)] = _LexiconIndex(exceptions)
    return index
