"""Sillabazione e posizione dell'accento in una parola."""
from __future__ import annotations

import re
import unicodedata

from .testo import _ACCENTED_VOWELS


_VOWELS = "aeiouàáèéìíòóùúïäëöü"
_STRONG_VOWELS = "aeoàáèéòóäëö"   # due vocali forti vicine formano sempre uno iato
_STRESSED_WEAK = "ìíùúïäëöü"  # i/u accentate e ogni vocale con dieresi (ï, ë, ö...): iato con la vocale vicina
_ONSET_DIGRAPHS = {"ch", "gh", "gn", "gl", "qu"}
_MUTE_LIQUID = re.compile(r"[bcdfgptv][lr]")


def _is_vowel(w: str, i: int) -> bool:
    """True se w[i] è una vocale. La u di 'qu' conta come consonante."""
    return w[i] in _VOWELS and not (w[i] == "u" and i > 0 and w[i - 1] == "q")


def _is_hiatus(w: str, i: int) -> bool:
    """True se tra w[i-1] e w[i] (entrambe vocali) passa un confine di sillaba."""
    prev, cur = w[i - 1], w[i]

    # i/u accentate o con dieresi spezzano il dittongo (pa-ù-ra, vi-sï-o-ne),
    # tranne 'più' e 'giù', dove l'accento è solo grafico.
    if prev in _STRESSED_WEAK or cur in _STRESSED_WEAK:
        return not (prev == "i" and cur in "ùú" and i == len(w) - 1)

    # Due vocali forti vicine formano uno iato (po-e-ta)
    if prev in _STRONG_VOWELS and cur in _STRONG_VOWELS:
        return True

    # u + i + vocale (buio, abbuia, annuiamo): l'i è una semiconsonante che passa alla sillaba dopo
    # (bu-io, ab-bu-ia). Non vale dopo q/g, dove la u è muta (qui-e-te, se-guia-mo).
    if prev == "u" and cur == "i" and i + 1 < len(w) and _is_vowel(w, i + 1) and not (i >= 2 and w[i - 2] in "qg"):
        return True

    # Forte + i/u + vocale: la semiconsonante passa alla sillaba dopo (ma-ia-le, a-iu-to)
    return (
        cur in "iu"
        and prev in _STRONG_VOWELS
        and i + 1 < len(w)
        and _is_vowel(w, i + 1)
    )


def _find_nuclei(w: str) -> list[tuple[int, int]]:
    """Restituisce l'intervallo (inizio, fine) di ogni nucleo vocalico (vocale, dittongo, trittongo)."""
    nuclei = []
    i = 0
    while i < len(w):
        if not _is_vowel(w, i):
            i += 1
            continue
        start = i
        i += 1
        while i < len(w) and _is_vowel(w, i) and not _is_hiatus(w, i):
            i += 1
        nuclei.append((start, i))
    return nuclei


def _is_onset(cluster: str) -> bool:
    """True se il gruppo di consonanti può aprire una sillaba."""
    if len(cluster) == 1 or cluster in _ONSET_DIGRAPHS or _MUTE_LIQUID.fullmatch(cluster):
        return True
    # s impura: sta davanti a un attacco legale, ma non si raddoppia (sp-, str-, sch-)
    return cluster[0] == "s" and cluster[1] != "s" and _is_onset(cluster[1:])


def _split_cluster(cluster: str) -> tuple[str, str]:
    """
    Divide le consonanti tra due nuclei in (coda, attacco).
    L'attacco è il suffisso più lungo che sia legale; un apostrofo finale ne fa parte.
    """
    apostrophe = ""
    if cluster.endswith("'"):
        cluster, apostrophe = cluster[:-1], "'"
    for i in range(len(cluster)):
        if _is_onset(cluster[i:]):
            return cluster[:i], cluster[i:] + apostrophe
    return cluster, apostrophe


# Interiezioni con h muta che la poesia conta come una sola sillaba (Dante: "Ahi quanto a dir...")
_ONE_SYLLABLE_INTERJECTIONS = frozenset({"ahi", "ehi", "ohi", "uhi", "ahi'", "ehi'"})


def syllabify_word(word: str) -> list[str]:
    """
    Divide una singola parola nelle sue sillabe grammaticali italiane.

    1. Trova i nuclei vocalici, distinguendo dittonghi e iati.
    2. Per ogni gruppo di consonanti tra due nuclei, l'attacco legale più lungo
       va alla sillaba seguente e il resto chiude la precedente.
    Le consonanti prima del primo nucleo e dopo l'ultimo restano nella prima
    e nell'ultima sillaba. Una parola senza vocali (es. "'n") non si divide.
    """
    if not isinstance(word, str):
        raise TypeError("La parola deve essere una stringa")

    w = unicodedata.normalize("NFC", word).lower()
    if w in _ONE_SYLLABLE_INTERJECTIONS:
        return [w]
    nuclei = _find_nuclei(w)
    if not nuclei:
        return [w] if w else []

    cuts = []
    for (_, end), (start, _) in zip(nuclei, nuclei[1:]):
        coda, _ = _split_cluster(w[end:start])
        cuts.append(end + len(coda))

    bounds = [0, *cuts, len(w)]
    return [w[a:b] for a, b in zip(bounds, bounds[1:])]


_APOCOPE_ENDINGS = "nrl"                       # cammin, amor, sol: troncamenti poetici
_FINAL_FALLING_DIPHTHONG = re.compile(r"[aeo][iu]$")   # ritrovai, vorrei, eroi, ormai


def get_stress_index(syllables: list[str]) -> int:
    """
    Restituisce l'indice (da 0) della sillaba tonica di una parola già sillabata.

    Va chiamata sulle sillabe della parola accentata da apply_stress_rules. Le regole,
    in ordine:
      1. se una sillaba porta l'accento grafico, è quella (virtù, ànima, perché);
      2. un monosillabo ha l'accento sull'unica sillaba;
      3. un imperfetto in -ean (tenean, avean, parean) ha l'accento sulla e;
         una parola che finisce per -n, -r, -l è tronca per apocope (cammin, amor, sol,
         ritornar): accento sull'ultima sillaba. Le altre consonanti finali (-s, -m, -t,
         -d, ...) sono di parole latine o straniere, di norma piane (gratis, album, virus);
      4. una parola che finisce con un dittongo discendente -ai, -ei, -oi, -au, -eu è tronca
         anche senza accento scritto, perché l'ortografia non lo richiede (ritrovai, vorrei,
         eroi, ormai, assai): accento sull'ultima sillaba;
      5. in tutti gli altri casi la parola è piana: accento sulla penultima sillaba.

    Eccezioni note, da risolvere accentando la parola nel lessico (la regola 1 vince su
    tutte): le parole straniere in -n, -r, -l (compùter) e le parole in -ei di origine
    sdrucciola (contemporànei, nùclei), che apply_stress_rules accenta già da sé.
    """
    if not isinstance(syllables, list) or not all(isinstance(s, str) for s in syllables):
        raise TypeError("Le sillabe devono essere una lista di stringhe")
    if not syllables:
        raise ValueError("La parola non ha sillabe")

    for i in range(len(syllables) - 1, -1, -1):
        if any(ch in _ACCENTED_VOWELS for ch in syllables[i]):
            return i

    if len(syllables) == 1:
        return 0

    last = syllables[-1].rstrip("'").casefold()
    # imperfetto in -ean (tenean, avean, parean: da -eano): accento sulla e, non sull'apocope
    if last == "an" and syllables[-2].casefold().rstrip("'")[-1:] == "e":
        return len(syllables) - 2
    if last and last[-1] not in _VOWELS:
        # tronca per apocope solo se finisce per n, r, l; altrimenti parola straniera o latina
        return len(syllables) - 1 if last[-1] in _APOCOPE_ENDINGS else len(syllables) - 2
    if _FINAL_FALLING_DIPHTHONG.search(last):
        return len(syllables) - 1
    return len(syllables) - 2
