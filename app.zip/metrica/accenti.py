"""Accentazione: regole sui suffissi, parole piane note, forme derivate dal lessico."""
from __future__ import annotations

import re

from .lessico import _LexiconIndex, _get_lexicon_index
from .sillabe import _STRONG_VOWELS, _find_nuclei
from .testo import _ACCENTED_VOWELS, _GRAVE, _WORD_CHUNKS_PATTERN, resolve_stress_conflicts


# ----------------------------------------------------------------------
# REGOLE PER LE PAROLE SDRUCCIOLE PREVEDIBILI (solo suffissi produttivi)
# ----------------------------------------------------------------------
# Ogni regola è (espressione regolare sulla parola senza accenti, é_chiusa).
# - Senza gruppo "v": l'accento cade sulla terzultima sillaba (parola sdrucciola).
# - Con gruppo "v": l'accento cade esattamente su quella vocale (es. ebràico, ove
#   la "i" è uno iato e la terzultima sillaba, per il sillabatore, sarebbe un'altra).
# Servono almeno tre sillabe, altrimenti la parola resta neutra (due sillabe = piana).
_SDRUCCIOLE_RULES = [
    (re.compile(r"issim[oaei]$"), False),                        # bellìssimo
    (re.compile(r"[aeiou]bil[ei]$"), False),                     # amàbile, incredìbile, mòbile
    (re.compile(r"evol[ei]$"), True),                            # piacévole
    (re.compile(r"(?:es|err)im[oaei]$"), False),                 # centèsimo, celebèrrimo
    (re.compile(r"tudin[ei]$"), False),                          # abitùdine
    # Solo il singolare (e -aggini): i plurali in -ini si confondono con quelli dei diminutivi
    # in -ino (cugini, parigini, passeggini sono piane).
    (re.compile(r"(?:agg|igg|ugg|ag)ine$|(?:agg|igg|ugg)ini$"), False),  # stupidàggine, ruggine, immàgine
    (re.compile(r"ifer[oaei]$"), False),                         # fruttìfero
    (re.compile(r"(?<=[bcgnrt])ivor[oaei]$"), False),            # carnìvoro (non: divora, livore)
    (re.compile(r"olog(?:o|a|i|he)$"), False),                   # psicòlogo
    (re.compile(r"[aei]log(?:o|hi)$"), False),                   # catàlogo, dialoghi (non: elogi)
    (re.compile(r"[aeiou]metr[oi]$"), False),                    # termòmetro, perìmetro
    (re.compile(r"[aio]graf[oi]$"), False),                      # fotògrafo, paràgrafo
    (re.compile(r"[aeiou]gen[oi]$"), False),                     # ossìgeno
    (re.compile(r"(?<=[stz])agon[oi]$"), False),                 # ottàgono, esàgono
    (re.compile(r"(?P<v>o)id[ei]$"), False),                     # asteròide
    # Aggettivi in -ico: le regole con "v" vengono prima di quella generale, che
    # altrimenti conterebbe come dittongo l'iato di ebraico, eroico, egoistico.
    (re.compile(r"(?P<v>[aeo])ic(?:[oai]|he)$"), False),         # ebràico, eròico, onomatopèico
    (re.compile(r"(?P<v>i)stic(?:[oai]|he)$"), False),           # egoìstico, artìstico
    (re.compile(r"ic(?:[oa]|he)$"), False),                      # tècnico, pràtica, pùbbliche
    # Il plurale in -ici è ambiguo: gli aggettivi in -ico sono sdruccioli (tècnici), ma i
    # plurali di nomi in -ice, -icio e -trice sono piani (radìci, edifìci, attrìci).
    # Si accentano quindi solo le terminazioni tipicamente aggettivali; il resto lo
    # coprono le forme derivate dal lessico.
    (re.compile(r"(?:[tgnmprsf]|ol|bl)ici$"), False),            # matemàtici, lògici, tècnici, tìpici
    # Terze persone plurali dei verbi: sono sempre sdrucciole e le terminazioni sono inequivocabili
    # (le forme in -ano/-ono del presente e in -avano/-evano/-ivano hanno invece omografi
    # piani come capitano e divano: stanno in sdrucciole_extra.json).
    (re.compile(r"ebbero$"), False),                             # sarèbbero, parlerèbbero
    (re.compile(r"[aeiou]ssero$"), False),                       # fòssero, dèssero, trovàssero
    (re.compile(r"ettero$"), False),                             # dovèttero, vendèttero
    (re.compile(r"(?:ar|er|ir|ur)ono$"), False),                 # andàrono, credèrono, usìrono, fùrono
    (re.compile(r"[aeiou](?:ng|lg|pr|fr)ono$"), False),          # appartèngono, sàlgono, àprono, òffrono
    (re.compile(r"(?<=.{2})[aei]vano$"), False),                 # vivèvano, sentìvano, trovàvano
    (re.compile(r"(?:ven|ten|ott|sost|mant|avv)nero$|[aeiou]nnero$"), False),  # vènnero, tènnero
    (re.compile(r"(?<=[aeiou])(?:[nrs])?sero$"), False),        # prèsero, rimàsero, giùnsero
    (re.compile(r"[aeiou]ssimo$"), False),                       # avéssimo, fòssimo, màssimo
    # Forme verbali con particelle enclitiche: l'accento resta sulla vocale del verbo
    # (basàndosi, facèndolo, fàtemi, ricordàtevi, prèndersi).
    (re.compile(r"(?P<v>[aei])ndo(?:mi|ti|ci|vi|si|li|le|lo|la|gli)$"), False),
    (re.compile(r"(?P<v>[aei])te(?:mi|ti|ci|vi|li|le|lo|la)$"), False),
    (re.compile(r"an(?:eo|ea|ee|ei)$"), False),                  # contemporàneo, spontànea
    (re.compile(r"(?<=[aeiou])poli$"), False),                   # Nàpoli, Trìpoli, necròpoli
    (re.compile(r"ac(?:eo|ea|ee|ei)$"), False),                  # cetàceo, cartàcea, crostàcei
]

# Parole piane che le regole e le forme derivate accentarebbero per errore: gli aggettivi in
# -ico hanno qualche eccezione ben nota, tra cui i nomi propri e i plurali in -ici di nomi piani.
_PLANE_WORDS = frozenset({
    "amico", "amica", "amici", "amiche", "nemico", "nemica", "nemici", "nemiche",
    "antico", "antica", "antiche", "mendico", "mendica", "mendici", "mendiche",
    "pudico", "pudica", "pudici", "pudiche", "fatica", "fatiche", "formica", "formiche",
    "ortica", "ortiche", "vescica", "vesciche", "ombelico", "benedico", "benedica",
    "enrico", "enrica", "federico", "federica", "ludovico", "ludovica", "lodovico",
    "ulrico", "teodorico", "alarico", "errico", "quirico", "mozambico",
    # plurali piani di nomi in -ice e -icio (qualcuno arriva dal lessico: benefìci da benèfico)
    "felici", "infelici", "radici", "edifici", "uffici", "sacrifici", "superfici",
    "cicatrici", "pendici", "matrici", "narici", "vernici", "appendici", "auspici",
    "alici", "artifici", "benefici", "cornici", "fenici", "federici", "lerici", "cubile", "cubili",
    # forme omografe di participi o nomi che il lessico accentarebbe per errore
    "seguiti", "seguite", "scalate", "abati", "nomini", "nicole", "arcore", "orologi",
    # senza l'accento finale scritto
    "poiche", "anziche",
    # omografi che le forme derivate accentarebbero per errore (tenera -> tenere)
    "tenere", "contenere", "ritenere", "mantenere", "ottenere", "sostenere", "trattenere", "appartenere",
    "portale", "portali", "subiti", "sedili", "pagani", "pagano", "testimoni", "barbera", "salvini",
    "repubblicano", "repubblicani", "repubblicana", "repubblicane", "intestino", "colosseo", "ubriachi",
})
_PLANE_FAMILIES = re.compile(r"\w+trici")   # plurali di nomi in -trice: attrìci, lavoratrìci


def _is_known_plane_word(chunk: str) -> bool:
    return chunk in _PLANE_WORDS or _PLANE_FAMILIES.fullmatch(chunk) is not None


_PREFIXES = tuple(sorted({
    "ab", "ac", "ad", "af", "ag", "al", "am", "an", "ap", "ar", "as", "at",
    "anti", "arci", "archi", "auto", "bene", "co", "col", "com", "con", "contro",
    "cor", "de", "di", "dis", "es", "extra", "fra", "il", "im", "in", "inter",
    "intra", "ir", "mal", "male", "mis", "non", "oltre", "per", "post", "pre",
    "pro", "ra", "re", "ri", "rin", "retro", "semi", "sopra", "sotto", "sovra",
    "stra", "sub", "super", "tra", "trans", "ultra", "vice",
    "aero", "bio", "eco", "elettro", "foto", "geo", "idro", "iper", "ipo", "macro",
    "micro", "mono", "moto", "multi", "poli", "psico", "radio", "tele", "termo", "video",
}, key=len, reverse=True))

# Una parola che finisce come un participio passato (-ato, -ito, -uto) non eredita
# l'accento di un sostantivo omografo: "conseguito" è piana anche se "séguito" è sdrucciola.
_PARTICIPLE_ENDING = re.compile(r"[aiu]t[aeio]$")

_MIN_ROOT_LENGTH = 5    # lettere minime della radice che resta dopo il prefisso
_MAX_PREFIXES = 2       # prefissi impilabili (ri + am + mettere)


def _accent_char(vowel: str, closed: bool = False) -> str:
    return "é" if closed and vowel == "e" else _GRAVE[vowel]


def _stressed_vowel_index(w: str, start: int, end: int) -> int:
    """Indice della vocale che porta l'accento in un nucleo vocalico w[start:end]."""
    for i in range(start, end):
        if w[i] in _STRONG_VOWELS:      # nel dittongo vince la vocale forte (pièno, cuòre, càuto)
            return i
    return end - 1                       # due deboli (iu, ui): vince la seconda (più, lùi)


def _accent_by_suffix(chunk: str) -> str:
    """Applica le regole sui suffissi sdruccioli; restituisce il blocco invariato se nessuna scatta."""
    nuclei = _find_nuclei(chunk)
    for pattern, closed in _SDRUCCIOLE_RULES:
        match = pattern.search(chunk)
        if not match:
            continue
        if "v" in pattern.groupindex:
            i = match.start("v")
            if i == 0:                   # serve una radice prima del suffisso
                continue
        elif len(nuclei) >= 3:
            i = _stressed_vowel_index(chunk, *nuclei[-3])
        else:
            continue                     # meno di tre sillabe: la parola è piana
        if chunk[i] in _GRAVE:           # la dieresi (ï) non si tocca
            return chunk[:i] + _accent_char(chunk[i], closed) + chunk[i + 1 :]
    return chunk


def _accent_with_prefixes(
    word: str, exceptions: dict[str, str], index: _LexiconIndex, depth: int
) -> str | None:
    """Toglie fino a `depth` prefissi finché trova una voce del lessico (riammèttere = ri + am + mèttere)."""
    for prefix in _PREFIXES:
        if not word.startswith(prefix):
            continue
        root = word[len(prefix) :]
        if len(root) < _MIN_ROOT_LENGTH:
            continue
        accented_root = exceptions.get(root) or index.derived.get(root)
        if accented_root is None and depth > 1:
            accented_root = _accent_with_prefixes(root, exceptions, index, depth - 1)
        if accented_root:
            return prefix + accented_root
    return None


def _accent_from_derived_forms(chunk: str, exceptions: dict[str, str], index: _LexiconIndex) -> str | None:
    """Cerca l'accento tra le forme derivate dal lessico (plurali, verbi) e nei composti con prefisso."""
    if chunk in index.derived:
        return index.derived[chunk]
    if _PARTICIPLE_ENDING.search(chunk):
        return None
    return _accent_with_prefixes(chunk, exceptions, index, _MAX_PREFIXES)


def _stress_chunk(chunk: str, exceptions: dict[str, str], index: _LexiconIndex) -> str:
    """Accenta un singolo blocco di lettere (es. 'anima' in "l'anima")."""
    # Già accentato (dall'utente o per natura): non si tocca
    if any(ch in _ACCENTED_VOWELS for ch in chunk):
        return chunk

    # 1. Voce esatta del dizionario: ha sempre l'ultima parola
    if chunk in exceptions:
        return exceptions[chunk]

    # 2. Parole piane note, che le forme derivate e i suffissi accentarebbero per errore
    if _is_known_plane_word(chunk):
        return chunk

    # 3. Forme derivate dal dizionario (plurali, verbi, composti)
    derived = _accent_from_derived_forms(chunk, exceptions, index)
    if derived is not None:
        return derived

    # 4. Suffissi prevedibili; altrimenti parola piana, tronca o monosillabo: resta neutra
    return _accent_by_suffix(chunk)


def apply_stress_rules(word: str, exceptions: dict[str, str]) -> str:
    """
    Arricchisce la parola con l'accento grafico esplicito quando non è piana.

    Per ogni blocco di lettere (gli apostrofi separano i blocchi, es. "l'" e "anima"):
      1. se è già accentato lo lascia com'è;
      2. cerca nel dizionario delle eccezioni: la voce esatta, le sue forme derivate
         (plurali, terza persona plurale dei verbi) e i composti con prefisso;
      3. applica le regole sui suffissi sdruccioli (-issimo, -abile, -ico...).
    Lascia inalterate le parole piane, tronche e i monosillabi.
    L'indice della sillaba tonica si ricava dopo la sillabazione con get_stress_index.
    """
    if not isinstance(word, str) or not isinstance(exceptions, dict):
        raise TypeError("Parametri non validi")

    # Pulisce preventivamente la parola da errori di battitura utente (doppi accenti)
    word = resolve_stress_conflicts(word)

    index = _get_lexicon_index(exceptions)
    return _WORD_CHUNKS_PATTERN.sub(lambda m: _stress_chunk(m.group(0), exceptions, index), word)
