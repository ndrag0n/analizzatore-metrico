"""Pulizia del verso ed estrazione delle parole; costanti sui caratteri e sugli accenti."""
from __future__ import annotations

import re
import unicodedata


_LETTERS = "A-Za-zÀÁÈÉÌÍÒÓÙÚÏÄËÖÜàáèéìíòóùúïäëöü"
_PUNCTUATION = ",.;:!?'\"«»“”()[]-–—…"
_ALLOWED_VERSE = re.compile(f"[{_LETTERS}{re.escape(_PUNCTUATION)} ]+")
_HAS_LETTER = re.compile(f"[{_LETTERS}]")
# L'accento circonflesso (tôr = torre, Petrarca) segna un troncamento: vale come accento sulla vocale
_CIRCUMFLEX = str.maketrans("âêîôûÂÊÎÔÛ", "àèìòùÀÈÌÒÙ")
_APOSTROPHES = str.maketrans({"’": "'", "‘": "'", "ʼ": "'"})
_WORD = re.compile(r"'?[^\W\d_]+(?:'[^\W\d_]+)*'?")

# Costanti per la gestione degli accenti
_ACCENTED_VOWELS = set("àáèéìíòóùú")
_STRIP_ACCENTS = str.maketrans("àáèéìíòóùú", "aaeeiioouu")
_GRAVE = {"a": "à", "e": "è", "i": "ì", "o": "ò", "u": "ù"}

# Regex che cattura esclusivamente i blocchi di lettere, ignorando l'apostrofo
_WORD_CHUNKS_PATTERN = re.compile(r"[a-zàáèéìíòóùúïäëöü]+")


def clean_verse(verse: str) -> str:
    """Pulisce e normalizza il verso, restituendo una stringa valida."""

    if not isinstance(verse, str):
        raise TypeError("Il verso deve essere una stringa")

    verse = unicodedata.normalize("NFC", verse).translate(_APOSTROPHES).translate(_CIRCUMFLEX)
    verse = " ".join(verse.split())

    if not verse:
        raise ValueError("Il verso non può essere vuoto")
    if any(char.isdigit() for char in verse):
        raise ValueError("Il verso non può contenere cifre numeriche")
    if not _ALLOWED_VERSE.fullmatch(verse):
        invalid = sorted({ch for ch in verse if not _ALLOWED_VERSE.fullmatch(ch)})
        raise ValueError("Il verso contiene caratteri non validi: " + " ".join(invalid))
    if not _HAS_LETTER.search(verse):
        raise ValueError("Il verso deve contenere almeno una lettera")

    return verse


def extract_words(verse: str) -> list[str]:
    """Restituisce le parole del verso in minuscolo, apostrofi inclusi."""

    if not isinstance(verse, str):
        raise TypeError("Il verso deve essere una stringa")
    verse = unicodedata.normalize("NFC", verse).lower()
    return _WORD.findall(verse)


def _resolve_chunk_conflicts(chunk: str) -> str:
    """Lascia un solo accento grafico in un blocco di lettere."""
    if sum(1 for ch in chunk if ch in _ACCENTED_VOWELS) <= 1:
        return chunk

    # CASO A: l'ultima lettera è accentata -> vince l'accento finale (es. 'cìttà' -> 'città')
    if chunk[-1] in _ACCENTED_VOWELS:
        return chunk[:-1].translate(_STRIP_ACCENTS) + chunk[-1]

    # CASO B: l'ultima lettera non è accentata -> regredisce del tutto (es. 'àncòra' -> 'ancora')
    return chunk.translate(_STRIP_ACCENTS)


def resolve_stress_conflicts(word: str) -> str:
    """
    Risolve i conflitti nelle parole che presentano più di un accento grafico.

    Come apply_stress_rules, ragiona per blocchi di lettere: gli apostrofi separano
    unità indipendenti ("l'àncòra" -> "l'ancora"), quindi un accento nel blocco
    "dov'" non può cancellare quello del blocco "è" di "dov'è".
    """
    if not isinstance(word, str):
        raise TypeError("Il verso o parola deve essere una stringa")

    return _WORD_CHUNKS_PATTERN.sub(lambda m: _resolve_chunk_conflicts(m.group(0)), word)
