"""Dal verso alle parole analizzate: accento, sillabe e indice della sillaba tonica."""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass

from .accenti import apply_stress_rules
from .lessico import _default_lexicon
from .sillabe import _VOWELS, get_stress_index, syllabify_word
from .testo import _ACCENTED_VOWELS, clean_verse, extract_words


# ---------------------------------------------------------------------------
# Dal verso alle parole analizzate
# ---------------------------------------------------------------------------

# Parole atone: articoli, preposizioni (semplici e articolate), congiunzioni e particelle non
# portano accento di verso quando non è scritto. Gli altri monosillabi (mar, sol, fior, tu,
# noi, ben...) sono considerati toni.
_ATONIC_WORDS = frozenset("""
il lo la i gli le un uno una
di a da in con su per tra fra
del al dal sul col nel dei ai dai sui coi nei
dello alla allo alle agli della delle degli dalla dallo dalle dagli
sulla sullo sulle sugli nella nello nelle negli
e ed et o od ma se che
mi ti ci vi si li ne
non
ch l d de s m t c v n dell all dall sull nell coll
""".split())   # nell'ultima riga le forme elise (ch', l', dell'...): una parola è atona se lo sono tutti i suoi pezzi


@dataclass(frozen=True)
class Word:
    """Una parola del verso, già accentata e sillabata."""

    text: str                    # come scritta dall'utente (minuscola, apostrofi inclusi)
    accented: str                # con gli accenti aggiunti da apply_stress_rules
    syllables: tuple[str, ...]
    stress_idx: int | None       # None per i monosillabi atoni
    stress_source: str           # "scritto", "regola", "lessico", "default" o "atona"


def _is_atonic(text: str) -> bool:
    """True se tutti i pezzi della parola (divisa agli apostrofi) sono atoni: "ch'i'", "dell'", "'l"."""
    pieces = [piece for piece in text.split("'") if piece]
    return bool(pieces) and all(piece in _ATONIC_WORDS for piece in pieces)


def _attach_vowelless(words: list[Word]) -> list[Word]:
    """
    Una parola senza vocali non è una sillaba. Se comincia con l'apostrofo ('l, 'n) si appoggia
    alla parola precedente (e'l, che'n, ebbe'l); se finisce con l'apostrofo (l', d', o uno spazio
    di troppo dopo l'elisione: "l' occhio") alla successiva; se il verso comincia con lei, anche
    alla successiva.
    """
    merged: list[Word] = []
    pending = ""
    for word in words:
        if not any(ch in _VOWELS for ch in word.accented):
            elided_prefix = word.text.endswith("'") and not word.text.startswith("'")
            if merged and not elided_prefix:
                previous = merged[-1]
                syllables = list(previous.syllables)
                syllables[-1] += word.accented
                merged[-1] = dataclasses.replace(
                    previous, text=f"{previous.text} {word.text}",
                    accented=f"{previous.accented} {word.accented}", syllables=tuple(syllables))
            else:
                pending = f"{pending}{word.accented}"
            continue
        if pending:
            syllables = list(word.syllables)
            syllables[0] = pending + syllables[0]
            word = dataclasses.replace(word, text=f"{pending} {word.text}", syllables=tuple(syllables))
            pending = ""
        merged.append(word)
    return merged


_NO_LEXICON: dict[str, str] = {}      # lessico vuoto condiviso: l'indice resta in cache


def _stress_source(text: str, accented: str, exceptions: dict[str, str]) -> str:
    if any(ch in _ACCENTED_VOWELS for ch in text):
        return "scritto"
    if accented == text:
        return "default"
    return "regola" if apply_stress_rules(text, _NO_LEXICON) == accented else "lessico"


def analyze_words(verse: str, exceptions: dict[str, str] | None = None) -> list[Word]:
    """
    Trasforma un verso in una lista di `Word`: accento, sillabe e indice della sillaba tonica.

    L'utente decide gli accenti che il programma non può indovinare scrivendoli nel verso:
    omografi (àncora/ancòra), parole straniere (compùter) e dieresi (vi-sïone). Un accento
    scritto non viene mai modificato e ha sempre la precedenza.
    """
    if exceptions is None:
        exceptions = _default_lexicon()
    words = []
    for text in extract_words(clean_verse(verse)):
        accented = apply_stress_rules(text, exceptions)
        syllables = syllabify_word(accented)
        has_accent = any(ch in _ACCENTED_VOWELS for ch in accented)
        if not has_accent and _is_atonic(text):
            stress_idx, source = None, "atona"
        else:
            stress_idx = get_stress_index(syllables)
            source = _stress_source(text, accented, exceptions)
        words.append(Word(text, accented, tuple(syllables), stress_idx, source))
    words = _attach_vowelless(words)
    last = words[-1] if words else None
    if len(words) > 1 and last.stress_idx is None and len(last.syllables) == 1:
        # un monosillabo atono in fine di verso porta l'ictus (…tra noi, che si): la rima lo rende tonico
        words[-1] = dataclasses.replace(last, stress_idx=0, stress_source="fine verso")
    return words
