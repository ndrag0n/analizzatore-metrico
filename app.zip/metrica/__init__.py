"""Analizzatore metrico dell'endecasillabo: accenti, sillabe, sinalefi, classificazione."""
from .accenti import apply_stress_rules
from .cli import main
from .lessico import load_exceptions
from .letture import find_metric_readings
from .parole import Word, analyze_words
from .presentazione import describe_failure, describe_scansion, render_scansion
from .scansione import ENDECASILLABO, License, MeterSpec, Scansion, metric_length, scan_verse
from .sillabe import get_stress_index, syllabify_word
from .testo import clean_verse, extract_words, resolve_stress_conflicts

__all__ = [
    "ENDECASILLABO", "License", "MeterSpec", "Scansion", "Word",
    "analyze_words", "apply_stress_rules", "clean_verse", "describe_failure",
    "describe_scansion", "extract_words", "find_metric_readings", "get_stress_index",
    "load_exceptions", "main", "metric_length", "render_scansion",
    "resolve_stress_conflicts", "scan_verse", "syllabify_word",
]
