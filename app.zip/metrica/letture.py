"""Letture metriche di un verso: sinalefe e dialefe."""
from __future__ import annotations

from itertools import product

from .parole import Word
from .sillabe import _VOWELS


# ---------------------------------------------------------------------------
# Letture metriche: sinalefe e dialefe
# ---------------------------------------------------------------------------

_MAX_COLLISIONS = 16   # 2**16 letture al massimo: oltre, il verso non è realistico


def _letters_only(syllable: str) -> str:
    return "".join(ch for ch in syllable.casefold() if ch.isalpha())


def _starts_with_vowel(syllable: str) -> bool:
    """True se la sillaba comincia con una vocale; la h iniziale è muta (ho amato)."""
    letters = _letters_only(syllable)
    if len(letters) > 1 and letters[0] == "h":
        letters = letters[1:]
    return bool(letters) and letters[0] in _VOWELS


def _ends_with_vowel(syllable: str) -> bool:
    """True se la sillaba finisce con una vocale; l'apostrofo finale (po') non conta."""
    letters = _letters_only(syllable)
    return bool(letters) and letters[-1] in _VOWELS


def _validate_words_data(words_data: list[dict]) -> None:
    if not isinstance(words_data, list):
        raise TypeError("words_data deve essere una lista di dizionari")
    for position, word in enumerate(words_data):
        if isinstance(word, Word):
            continue
        if not isinstance(word, dict):
            raise TypeError(f"words_data[{position}] deve essere un dizionario")
        for key in ("syllables", "stress_idx"):
            if key not in word:
                raise ValueError(f"words_data[{position}] non ha la chiave '{key}'")
        syllables, stress = word["syllables"], word["stress_idx"]
        if not isinstance(syllables, list) or not all(isinstance(s, str) for s in syllables):
            raise TypeError(f"words_data[{position}]['syllables'] deve essere una lista di stringhe")
        if not syllables or not all(syllables):
            raise ValueError(f"words_data[{position}]['syllables'] non può essere vuoto né contenere sillabe vuote")
        if stress is not None:
            if isinstance(stress, bool) or not isinstance(stress, int):
                raise TypeError(f"words_data[{position}]['stress_idx'] deve essere un intero o None")
            if not 0 <= stress < len(syllables):
                raise ValueError(f"words_data[{position}]['stress_idx'] fuori dall'intervallo delle sillabe")


def find_metric_readings(words_data: list[dict]) -> list[dict]:
    """
    Elenca tutte le letture metriche possibili di un verso, scegliendo per ogni incontro di
    vocali tra due parole se fare sinalefe (le due sillabe si fondono) o dialefe (restano separate).

    Ogni elemento di `words_data` è un dizionario con:
      - "syllables": le sillabe della parola;
      - "stress_idx": indice della sillaba tonica, oppure None per le parole atone;
      - "text": il testo (facoltativo, non usato).

    C'è un incontro di vocali quando una parola finisce con una vocale (anche tonica, anche
    dopo un apostrofo: virtù, po') e la successiva comincia con una vocale (la h iniziale è
    muta). Con k incontri le letture sono 2**k, tutte distinte; la prima è quella con tutte
    le sinalefi, l'ultima quella con tutte le dialefi.

    Ogni lettura è un dizionario con:
      - "metric_syllables": le sillabe metriche; quelle fuse sono unite da "_" (va_o);
      - "stress_positions": gli indici metrici delle sillabe toniche, in ordine crescente e
        senza ripetizioni (se due toniche si fondono, l'indice compare una volta sola);
      - "elisions": gli indici delle parole il cui confine con la successiva è una sinalefe;
      - "dialefi": gli indici dei confini con incontro di vocali lasciati come dialefe.

    Gli elementi di `words_data` possono essere anche oggetti `Word`.

    Solleva TypeError per tipi errati, ValueError per dati incoerenti o per più di
    _MAX_COLLISIONS incontri di vocali.
    """
    _validate_words_data(words_data)
    if not words_data:
        return []
    words_data = [
        {"syllables": list(w.syllables), "stress_idx": w.stress_idx} if isinstance(w, Word) else w
        for w in words_data
    ]

    collisions = [
        _ends_with_vowel(words_data[i]["syllables"][-1])
        and _starts_with_vowel(words_data[i + 1]["syllables"][0])
        for i in range(len(words_data) - 1)
    ]
    collision_points = [i for i, found in enumerate(collisions) if found]
    if len(collision_points) > _MAX_COLLISIONS:
        raise ValueError(f"Troppi incontri di vocali ({len(collision_points)}): massimo {_MAX_COLLISIONS}")

    readings = []
    for choice in product((True, False), repeat=len(collision_points)):
        fused = {point for point, merge in zip(collision_points, choice) if merge}
        metric: list[str] = []
        stressed: list[bool] = []
        for w, word in enumerate(words_data):
            for j, syllable in enumerate(word["syllables"]):
                is_stressed = word["stress_idx"] == j
                if j == 0 and (w - 1) in fused:
                    metric[-1] += "_" + syllable
                    stressed[-1] = stressed[-1] or is_stressed
                else:
                    metric.append(syllable)
                    stressed.append(is_stressed)
        readings.append({
            "metric_syllables": metric,
            "stress_positions": [k for k, flag in enumerate(stressed) if flag],
            "elisions": sorted(fused),
            "dialefi": [point for point in collision_points if point not in fused],
        })
    return readings
