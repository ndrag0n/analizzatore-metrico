"""Ponte per la pagina web: l'analisi di una poesia come dati semplici (liste e dizionari JSON)."""
from __future__ import annotations

from .poesia import VerseResult, analyze_poem, summarize
from .presentazione import describe_scansion
from .spiegazione import explain_verse
from .scansione import Scansion, metric_length, split_stresses
from .tavola import Style, place_roles, render_poem, scansion_cells, scansion_notes


def _scansion_data(scansion: Scansion) -> dict:
    return {
        "kind": scansion.kind,
        "ending": scansion.ending,
        "stresses": list(scansion.stresses),
        "ictus": list(split_stresses(scansion.stresses)[0]),
        "toniche": list(split_stresses(scansion.stresses)[1]),
        "length": metric_length(scansion.reading),
        "syllables": len(scansion.reading["metric_syllables"]),
        "cells": scansion_cells(scansion),
        "notes": scansion_notes(scansion),
        "sentence": describe_scansion(scansion),
    }


def _verse_data(result: VerseResult) -> dict:
    if result.is_break:
        return {"break": True}
    data = {
        "break": False, "number": result.number, "text": result.text,
        "ok": result.ok, "error": result.error, "failure": result.failure, "suggestions": list(result.suggestions),
        "words": ["-".join(w.syllables) for w in result.words],
    }
    data["steps"] = [{"title": step.titolo, "lines": list(step.righe)} for step in explain_verse(result)]
    if result.scansion:
        data.update(_scansion_data(result.scansion))
        data["ambiguous"] = result.scansion.ambiguous
        data["alternatives"] = [_scansion_data(alt) for alt in result.scansion.alternatives]
    elif result.attempt:
        data["attempt"] = _scansion_data(result.attempt)
    return data


def analyze_for_web(text: str, max_licenses: int = 2) -> dict:
    """Restituisce {"verses": [...], "summary": str, "plain": str}, tutto serializzabile in JSON."""
    results = analyze_poem(text, max_licenses=max_licenses)
    verses = [r for r in results if not r.is_break]
    return {
        "verses": [_verse_data(r) for r in results],
        "places": {str(place): role for place, role in place_roles().items()},
        "summary": summarize(results) if len(verses) > 1 else "",
        "plain": render_poem(results, Style(False), 100),
    }
