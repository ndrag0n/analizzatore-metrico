"""Analisi di un testo di più versi (una poesia incollata o letta da file)."""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass

from .lessico import _default_lexicon
from .parole import Word, analyze_words
from .presentazione import describe_failure
from .suggerimenti import suggest_licenses, suggest_variants
from .scansione import ENDECASILLABO, MeterSpec, Scansion, closest_scansion, scan_verse
from .testo import clean_verse


@dataclass(frozen=True)
class VerseResult:
    """Esito per una riga del testo: un verso analizzato, una riga non analizzabile o uno stacco."""

    number: int | None                 # numero progressivo del verso; None per lo stacco tra strofe
    text: str
    words: tuple[Word, ...] = ()
    scansion: Scansion | None = None
    failure: str | None = None         # perché nessuna lettura rispetta il metro
    attempt: Scansion | None = None    # la lettura più vicina al metro, per mostrare le sillabe
    error: str | None = None           # riga non analizzabile (cifre, caratteri strani, troppe vocali)
    suggestions: tuple[str, ...] = ()  # ipotesi (iati, accenti, licenze) che renderebbero valido il verso

    @property
    def is_break(self) -> bool:
        return self.number is None

    @property
    def ok(self) -> bool:
        return self.scansion is not None


def analyze_poem(
    text: str,
    exceptions: dict[str, str] | None = None,
    spec: MeterSpec = ENDECASILLABO,
    max_licenses: int = 2,
) -> list[VerseResult]:
    """
    Analizza un verso per riga. Le righe vuote separano le strofe (se ne tiene una sola e mai
    all'inizio o alla fine); una riga che non si può analizzare non ferma le altre.
    """
    if exceptions is None:
        exceptions = _default_lexicon()
    results: list[VerseResult] = []
    number = 0
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            if results and not results[-1].is_break:
                results.append(VerseResult(None, ""))
            continue
        number += 1
        try:
            words = analyze_words(clean_verse(line), exceptions)
            scansion = scan_verse(words, spec, max_licenses)
        except (ValueError, TypeError) as error:
            results.append(VerseResult(number, line, error=str(error)))
            continue
        failure = attempt = None
        suggestions: list[str] = []
        if scansion is None:
            failure = describe_failure(words, spec, max_licenses)
            attempt = closest_scansion(words, spec, max_licenses)
            if max_licenses < 2:
                hint = suggest_licenses(words, spec)
                if hint:
                    suggestions.append(hint)
            suggestions += suggest_variants(line, exceptions, spec, max(max_licenses, 2))
        results.append(VerseResult(number, line, tuple(words), scansion, failure, attempt=attempt,
                                   suggestions=tuple(suggestions[:3])))
    while results and results[-1].is_break:
        results.pop()
    return results


_ENDING_NAMES = {
    "tronco": ("tronco", "tronchi"), "piano": ("piano", "piani"),
    "sdrucciolo": ("sdrucciolo", "sdruccioli"), "irregolare": ("irregolare", "irregolari"),
}


def _ending_name(ending: str, count: int) -> str:
    """Singolare o plurale della chiusura: bisdrucciolo -> bisdruccioli."""
    if ending in _ENDING_NAMES:
        return _ENDING_NAMES[ending][count != 1]
    return ending if count == 1 else ending[:-1] + "i"


def summarize(results: list[VerseResult], spec: MeterSpec = ENDECASILLABO) -> str:
    """Una frase di riepilogo: quanti versi, di che tipo, quali non riconosciuti."""
    verses = [r for r in results if not r.is_break]
    if not verses:
        return "Nessun verso da analizzare."
    good = [r.scansion for r in verses if r.ok]
    bad = [r.number for r in verses if not r.ok]
    head = f"{len(verses)} {'verso' if len(verses) == 1 else 'versi'}"
    clauses = []
    if good:
        kinds = Counter(s.kind for s in good if s.kind)
        endings = Counter(s.ending for s in good)
        detail = [f"{n} {kind}" for kind, n in kinds.items()]
        detail += [f"{n} {_ending_name(e, n)}" for e, n in endings.items()]
        clauses.append(f"{len(good)} riconosciuti come {spec.name} ({', '.join(detail)})")
    if bad:
        shown = ", ".join(str(n) for n in bad[:10]) + ("…" if len(bad) > 10 else "")
        clauses.append(f"{len(bad)} non riconosciuti (versi {shown})")
    return head + ": " + "; ".join(clauses) + "."
