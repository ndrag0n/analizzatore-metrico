"""Classificazione metrica: sedi accentate, tipo di verso, dieresi e sineresi."""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from itertools import combinations

from .letture import _letters_only, find_metric_readings
from .parole import Word
from .sillabe import _VOWELS, _find_nuclei


# ---------------------------------------------------------------------------
# Classificazione metrica
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class MeterSpec:
    """
    Descrive un verso con dati, non con codice. Le posizioni (le "sedi") si contano da 1.

    `required_stress`: sedi che devono portare l'ictus; per l'endecasillabo solo la
    decima, perché la lunghezza dipende dall'ultimo ictus (un verso tronco ha 10 sillabe,
    uno piano 11, uno sdrucciolo 12, e così via fino ai quintisdruccioli: sono tutti endecasillabi).
    `kinds`: i tipi canonici, in ordine di priorità: il primo le cui sedi sono tutte accentate.
    `other_kind`: il nome dei versi validi che non rientrano in nessun tipo canonico.
    """

    name: str
    required_stress: tuple[int, ...]
    kinds: tuple[tuple[str, tuple[int, ...]], ...] = ()
    other_kind: str | None = None


ENDECASILLABO = MeterSpec(
    name="endecasillabo",
    required_stress=(10,),
    kinds=(("a maiore", (6,)), ("a minore", (4,))),
    other_kind="non canonico",
)


@dataclass(frozen=True)
class License:
    """Una licenza poetica interna alla parola: dieresi (dittongo -> iato) o sineresi (iato -> dittongo)."""

    kind: str          # "dieresi" o "sineresi"
    word_index: int
    text: str
    weight: float = 1.0    # quanto è lontana dall'uso normale: più è alto, più è forzata (vedi _dieresi_weight)


@dataclass(frozen=True)
class Scansion:
    """Esito della scansione di un verso con una lettura precisa."""

    meter: str
    kind: str | None             # "a maiore", "a minore", "non canonico", ...
    ending: str                  # "tronco", "piano", "sdrucciolo", "bisdrucciolo"... o "irregolare"
    stresses: tuple[int, ...]    # sedi accentate, contate da 1
    reading: dict
    words: tuple[Word, ...] = ()
    licenses: tuple[License, ...] = ()      # dieresi e sineresi usate
    cost: int = 0                           # licenze più dialefi: meno è più naturale
    penalty: float = 0.0                    # come cost, ma pesato: la dieresi di "pien" pesa più di una dialefe dopo vocale tonica
    ambiguous: bool = False                 # altre letture di pari costo con ictus diversi
    alternatives: tuple["Scansion", ...] = field(default=())


def _last_stress_place(reading: dict) -> int | None:
    stresses = reading["stress_positions"]
    return stresses[-1] + 1 if stresses else None


def metric_length(reading: dict) -> int | None:
    """Sillabe contate dalla metrica: ultima sede accentata più una (l'endecasillabo ne ha 11)."""
    place = _last_stress_place(reading)
    return place + 1 if place else None


# Sillabe dopo l'ultimo ictus -> nome della chiusura del verso (accento su ultima, penultima,
# terzultima, quartultima... sillaba). Oltre le sei sillabe il verso è "irregolare".
_ENDINGS = {
    0: "tronco", 1: "piano", 2: "sdrucciolo", 3: "bisdrucciolo",
    4: "trisdrucciolo", 5: "quadrisdrucciolo", 6: "quintisdrucciolo",
}


def _verse_ending(reading: dict) -> str:
    after_last_stress = len(reading["metric_syllables"]) - 1 - reading["stress_positions"][-1]
    return _ENDINGS.get(after_last_stress, "irregolare")


def _fits(reading: dict, spec: MeterSpec) -> bool:
    stressed = {position + 1 for position in reading["stress_positions"]}
    last = _last_stress_place(reading)
    return last == max(spec.required_stress) and set(spec.required_stress) <= stressed


def split_stresses(
    stresses: tuple[int, ...], spec: MeterSpec = ENDECASILLABO
) -> tuple[tuple[int, ...], tuple[int, ...]]:
    """
    Divide le sedi toniche (contate da 1) in (ictus principali, altre sillabe toniche).
    Sono ictus principali l'ultima sede tonica e le sedi cardine del metro (per l'endecasillabo
    4ª, 6ª e 10ª); le altre toniche sono accenti di parola in sedi non cardine (2ª, 7ª, 8ª...).
    """
    if not stresses:
        return (), ()
    cardinal = set(spec.required_stress) | {p for _, places in spec.kinds for p in places}
    main = tuple(p for p in stresses if p in cardinal or p == stresses[-1])
    return main, tuple(p for p in stresses if p not in main)


def _kind(reading: dict, spec: MeterSpec) -> str | None:
    stressed = {position + 1 for position in reading["stress_positions"]}
    for name, places in spec.kinds:
        if set(places) <= stressed:
            return name
    return spec.other_kind


# --- Licenze interne alla parola: dieresi e sineresi ------------------------

def _is_silent_weak(word: str, i: int) -> bool:
    """True se la i/u in word[i] è solo grafica (cia, gio, glio, gnia, quo, guo) e non può essere spezzata."""
    letter, before = word[i], word[max(i - 1, 0):i]
    if i == 0:
        return False
    if letter == "i":
        return before in ("c", "g") or word[max(i - 2, 0):i] in ("gl", "gn")
    return before in ("q", "g")


def _split_diphthong(word: Word, syllable_index: int, cut: int) -> Word:
    syllable = word.syllables[syllable_index]
    syllables = list(word.syllables)
    syllables[syllable_index:syllable_index + 1] = [syllable[:cut], syllable[cut:]]
    stress = word.stress_idx
    if stress is not None:
        if stress > syllable_index:
            stress += 1
        elif stress == syllable_index and len(word.syllables) > 1:
            stress += 1          # in una parola di più sillabe l'accento resta sulla vocale forte
    return dataclasses.replace(word, syllables=tuple(syllables), stress_idx=stress)


def _merge_syllables(word: Word, index: int) -> Word:
    syllables = list(word.syllables)
    syllables[index:index + 2] = [syllables[index] + syllables[index + 1]]
    stress = word.stress_idx
    if stress is not None and stress > index:
        stress -= 1
    return dataclasses.replace(word, syllables=tuple(syllables), stress_idx=stress)


# Pesi delle licenze e delle dialefi: servono a scegliere, tra le letture che danno il verso
# giusto, la più naturale. Seguono la prassi descritta da Beltrami (La metrica italiana, §§114-120)
# e da Menichetti: la dialefe prevale sulla dieresi; la dieresi è tanto più forzata quanto più
# contraddice l'etimologia (pieno, fiato, buono); tutto resta ammesso, perché la poesia
# moderna è più libera di quella di Dante e Petrarca.
_W_SINERESI = 1.0
_W_DIERESI = 1.6                  # i/u atona + vocale tonica (disïato, obliar): normale e frequente
_W_DIERESI_EXCEPTIONAL = 2.2      # "dieresi d'eccezione" di mio, io, suo, più, lui...: ammessa ma non preferita
_W_DIERESI_UNSTRESSED = 3.0       # due atone (superbïa, esempïo): serve di solito a fare versi sdruccioli
_W_DIERESI_ETYMOLOGICAL = 4.0     # ie/uo toniche (piede, buono), pl-/fl-/bl-/cl- + i (fiato, piano, chiaro)

_EXCEPTIONAL_DIERESIS = frozenset({
    "io", "mio", "mia", "mie", "miei", "tuo", "tua", "tue", "tuoi", "suo", "sua", "sue", "suoi",
    "dio", "via", "pia", "pio", "due", "lui", "cui", "fui", "più", "giù", "noi", "voi", "poi",
    "mai", "lei", "dei", "sei", "colui", "altrui",
})


def _dieresi_weight(word: Word, syllable_index: int, cut: int) -> float:
    """Peso della dieresi che spezza word.syllables[syllable_index] prima della lettera `cut`."""
    syllable = word.syllables[syllable_index].casefold()
    letters = _letters_only(word.text)
    if letters in _EXCEPTIONAL_DIERESIS:
        return _W_DIERESI_EXCEPTIONAL
    first, second = syllable[cut - 1], syllable[cut]
    stressed = word.stress_idx == syllable_index
    if stressed and first + second in ("ie", "uo"):
        return _W_DIERESI_ETYMOLOGICAL
    before = syllable[cut - 2] if cut >= 2 else ""
    if stressed and first == "i" and before and before in "fpbh":
        return _W_DIERESI_ETYMOLOGICAL
    if not stressed:
        return _W_DIERESI_UNSTRESSED
    return _W_DIERESI


def _final_nexus(word: Word) -> bool:
    """
    True per le parole che finiscono con vocale tonica + vocale atona (avea, dicea, venìa, disìo, altrùi,
    cortesìa, e gli imperfetti in -ean: tenean): dentro il verso la tradizione le conta come una sillaba sola (Beltrami §117), in fine di
    verso come due.
    """
    syllables = word.syllables
    if len(syllables) < 2 or word.stress_idx != len(syllables) - 2:
        return False
    if any(ch in "äëïöü" for ch in syllables[-2].casefold() + syllables[-1].casefold()):
        return False                  # la dieresi scritta dall'autore (mäi, pïa) non si scioglie
    last = _letters_only(syllables[-1])
    penult = _letters_only(syllables[-2])
    if not penult or penult[-1] not in _VOWELS:
        return False
    return (len(last) == 1 and last in _VOWELS) or (last == "an" and penult[-1] == "e")   # avea, venìa; tenean


def _license_options(word: Word) -> list[tuple[str, Word, float]]:
    """Tutte le varianti della parola con una sola dieresi o una sola sineresi, con il loro peso."""
    options = []
    for k, syllable in enumerate(word.syllables):
        low = syllable.casefold()
        for start, end in _find_nuclei(low):
            for j in range(start + 1, end):
                # dittongo ascendente: i/u atona seguita da una vocale, non solo grafica
                if low[j - 1] in "iu" and low[j] in _VOWELS and not _is_silent_weak(low, j - 1):
                    options.append(("dieresi", _split_diphthong(word, k, j), _dieresi_weight(word, k, j)))
    for k in range(len(word.syllables) - 1):
        left, right = _letters_only(word.syllables[k]), _letters_only(word.syllables[k + 1])
        if left and right and left[-1] in _VOWELS and right[0] in _VOWELS:
            options.append(("sineresi", _merge_syllables(word, k), _W_SINERESI))
    return options


MAX_VERSE_SYLLABLES = 30      # oltre, la riga non è un verso (e la ricerca delle letture diventerebbe lentissima)


def _candidate_readings(words: list[Word], max_licenses: int):
    """Genera (licenze, parole modificate, lettura) per tutte le combinazioni di al più `max_licenses` licenze."""
    total = sum(len(word.syllables) for word in words)
    if total > MAX_VERSE_SYLLABLES:
        raise ValueError(f"La riga è troppo lunga per essere un verso ({total} sillabe grammaticali, massimo {MAX_VERSE_SYLLABLES})")
    base = list(words)
    unmerged: dict[int, Word] = {}
    for i, word in enumerate(words[:-1]):          # in fine di verso il nesso resta di due sillabe
        if _final_nexus(word):
            unmerged[i] = word
            base[i] = _merge_syllables(word, len(word.syllables) - 2)
    options = [(i, kind, changed, weight) for i, w in enumerate(base) for kind, changed, weight in _license_options(w)]
    options += [(i, "dieresi", word, _W_DIERESI_EXCEPTIONAL) for i, word in unmerged.items()]
    for count in range(max_licenses + 1):
        for combo in combinations(options, count):
            indices = [item[0] for item in combo]
            if len(set(indices)) < count:
                continue                         # al massimo una licenza per parola
            modified = list(base)
            for index, _, changed, _ in combo:
                modified[index] = changed
            licenses = tuple(License(kind, index, words[index].text, weight) for index, kind, _, weight in combo)
            for reading in find_metric_readings(modified):
                yield licenses, tuple(modified), reading


# Costo di una dialefe, dalla più alla meno probabile (Beltrami §120): dopo vocale tonica o nesso
# tonica + atona; dopo che/ma/se/o/e; tra atona e tonica; tra due atone; dopo parola sdrucciola.
_W_DIALEFE_TONIC = 0.6
_W_DIALEFE_PARTICLE = 0.8
_W_DIALEFE_ATONE_TONIC = 1.0
_W_DIALEFE_ATONES = 1.2
_W_DIALEFE_SDRUCCIOLA = 1.5
_DIALEFE_PARTICLES = frozenset({"che", "ma", "se", "o", "e", "ed"})


def _dialefe_weight(left: Word, right: Word) -> float:
    if left.stress_idx == len(left.syllables) - 1:
        return _W_DIALEFE_TONIC
    if _letters_only(left.text) in _DIALEFE_PARTICLES:
        return _W_DIALEFE_PARTICLE
    if left.stress_idx is not None and left.stress_idx <= len(left.syllables) - 3:
        return _W_DIALEFE_SDRUCCIOLA
    if right.stress_idx == 0:
        return _W_DIALEFE_ATONE_TONIC
    return _W_DIALEFE_ATONES


def _penalty(licenses, modified, reading: dict) -> float:
    """Peso complessivo di una lettura: licenze e dialefi, ognuna col suo peso."""
    total = sum(license.weight for license in licenses)
    for i in reading["dialefi"]:
        total += _dialefe_weight(modified[i], modified[i + 1])
    return round(total, 3)


def _make_scansion(spec: MeterSpec, licenses, modified, reading: dict, cost: int, penalty: float = 0.0) -> Scansion:
    return Scansion(
        meter=spec.name, kind=_kind(reading, spec), ending=_verse_ending(reading),
        stresses=tuple(p + 1 for p in reading["stress_positions"]), reading=reading,
        words=tuple(modified), licenses=licenses, cost=cost, penalty=penalty,
    )


def closest_scansion(
    words: list[Word], spec: MeterSpec = ENDECASILLABO, max_licenses: int = 2
) -> Scansion | None:
    """
    Per un verso che non rispetta `spec`: la lettura che gli si avvicina di più, così da poter
    mostrare le sillabe e il loro numero. Si preferisce la lunghezza metrica più vicina a quella
    del metro (per l'endecasillabo 11) e, a parità, la lettura più naturale (peso minore).
    Il campo `kind` è None. Restituisce None se il verso non ha sillabe accentate.
    """
    target = max(spec.required_stress) + 1
    best = None
    for licenses, modified, reading in _candidate_readings(words, max_licenses):
        length = metric_length(reading)
        if length is None:
            continue
        cost = len(licenses) + len(reading["dialefi"])
        penalty = _penalty(licenses, modified, reading)
        key = (abs(length - target), penalty, len(reading["dialefi"]))
        if best is None or key < best[0]:
            best = (key, licenses, modified, reading, cost, penalty)
    if best is None:
        return None
    _, licenses, modified, reading, cost, penalty = best
    return dataclasses.replace(_make_scansion(spec, licenses, modified, reading, cost, penalty), kind=None)


# Letture con peso entro questa distanza dalla migliore sono "alternative" plausibili.
_ALTERNATIVE_MARGIN = 0.5


def scan_verse(
    words: list[Word], spec: MeterSpec = ENDECASILLABO, max_licenses: int = 2
) -> Scansion | None:
    """
    Cerca la lettura di `words` che rispetta il verso `spec`, usando solo le licenze necessarie.

    Ogni lettura ha un peso: la somma dei pesi delle dialefi e di dieresi e sineresi (al più
    `max_licenses`), dove una dialefe dopo vocale tonica pesa meno di una dieresi, e la dieresi
    di "pien" più di quella di "io". Vince la lettura di peso minimo; le altre letture entro
    `_ALTERNATIVE_MARGIN` sono in `alternatives`, e `ambiguous` indica se hanno ictus diversi.
    Restituisce None se nessuna lettura è compatibile.
    """
    found = []
    for licenses, modified, reading in _candidate_readings(words, max_licenses):
        if not _fits(reading, spec):
            continue
        cost = len(licenses) + len(reading["dialefi"])
        found.append((_penalty(licenses, modified, reading), len(reading["dialefi"]), cost, licenses, modified, reading))
    if not found:
        return None
    found.sort(key=lambda item: (item[0], item[1]))
    best_penalty = found[0][0]
    candidates = [
        _make_scansion(spec, licenses, modified, reading, cost, penalty)
        for penalty, _, cost, licenses, modified, reading in found
        if penalty <= best_penalty + _ALTERNATIVE_MARGIN
    ]
    best, others = candidates[0], candidates[1:]
    ambiguous = any(other.stresses != best.stresses for other in others)
    return dataclasses.replace(best, ambiguous=ambiguous, alternatives=tuple(others))
