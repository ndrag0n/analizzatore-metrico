"""Modalità didattica: il ragionamento che porta dal verso alla sua scansione, passo per passo."""
from __future__ import annotations

from dataclasses import dataclass

from .letture import _letters_only
from .parole import Word
from .poesia import VerseResult
from .scansione import ENDECASILLABO, MeterSpec, Scansion, _is_silent_weak, split_stresses
from .sillabe import _VOWELS, _find_nuclei
from .tavola import _with_accent, scansion_cells
from .terminologia import chiusura_aggettivo, misura_del, nome_metro


@dataclass(frozen=True)
class Passo:
    titolo: str
    righe: tuple[str, ...]


def _ordinals(places) -> str:
    return " ".join(f"{p}ª" for p in places)


def _reason(word: Word) -> str:
    """Perché la parola ha quell'accento tonico."""
    n = len(word.syllables)
    if word.stress_source == "atona":
        return "atona: si appoggia alla parola vicina e non porta ictus da sola"
    if word.stress_source == "fine verso":
        return "monosillabo atono in fine di verso: porta l'ictus"
    if word.stress_source == "scritto":
        return "accento scritto da te"
    if word.stress_source == "regola":
        return "regola sul suffisso: parola non piana"
    if word.stress_source == "lessico":
        return "accento preso dal dizionario"
    if n == 1:
        return "monosillabo tonico"
    if word.stress_idx == n - 1:
        return "parola tronca: finale in -n, -r, -l o in dittongo discendente"
    return "parola piana: accento sulla penultima sillaba"


def _vowel_groups(word: Word) -> list[str]:
    """Dittonghi, trittonghi e iati della parola."""
    notes = []
    for syllable in word.syllables:
        low = syllable.casefold()
        for start, end in _find_nuclei(low):
            sounding = [low[i] for i in range(start, end) if not _is_silent_weak(low, i)]
            if len(sounding) >= 3:
                notes.append(f"trittongo «{''.join(sounding)}»")
            elif len(sounding) == 2:
                notes.append(f"dittongo «{''.join(sounding)}»")
    for left, right in zip(word.syllables, word.syllables[1:]):
        a, b = _letters_only(left), _letters_only(right)
        if a and b and a[-1] in _VOWELS and b[0] in _VOWELS:
            notes.append(f"iato «{a[-1]}-{b[0]}»")
    return notes


def _word_line(word: Word) -> str:
    syllables = list(word.syllables)
    if word.stress_idx is not None and len(syllables) > 1:
        syllables[word.stress_idx] = _with_accent(syllables[word.stress_idx])
    count = "1 sillaba" if len(syllables) == 1 else f"{len(syllables)} sillabe"
    line = f"{word.text}  →  {'-'.join(syllables)}  ({count}; {_reason(word)}"
    groups = _vowel_groups(word)
    return line + (f"; {', '.join(groups)})" if groups else ")")


def explain_verse(result: VerseResult, spec: MeterSpec = ENDECASILLABO) -> list[Passo]:
    """I passi del ragionamento per un verso già analizzato (vuoto se la riga non era analizzabile)."""
    scansion: Scansion | None = result.scansion or result.attempt
    if result.is_break or result.error or scansion is None:
        return []
    reading = scansion.reading
    steps = [Passo("Le parole: accento tonico e sillabe grammaticali",
                   tuple(_word_line(w) for w in result.words))]

    # incontri di vocali tra parole
    points = sorted(set(reading["elisions"]) | set(reading["dialefi"]))
    lines = []
    for index in points:
        a, b = scansion.words[index], scansion.words[index + 1]
        if index in reading["elisions"]:
            lines.append(f"«{a.text}» + «{b.text}»: sinalefe, le due vocali formano una sola sillaba metrica ({a.text}‿{b.text})")
        else:
            lines.append(f"«{a.text}» + «{b.text}»: dialefe, le due vocali restano in sillabe separate")
    steps.append(Passo("Incontri tra vocali di parole vicine",
                       tuple(lines) or ("Nessuna parola finisce per vocale davanti a una che comincia per vocale.",)))

    if scansion.licenses:
        lines = []
        for lic in scansion.licenses:
            what = ("il dittongo si legge come iato" if lic.kind == "dieresi"
                    else "l'iato si legge come dittongo")
            lines.append(f"«{lic.text}»: {lic.kind}, {what}")
        steps.append(Passo("Licenze dentro la parola", tuple(lines)))

    grammatical = sum(len(w.syllables) for w in result.words)
    fusions = len(reading["elisions"])
    splits = sum(1 for lic in scansion.licenses if lic.kind == "dieresi")
    merges = sum(1 for lic in scansion.licenses if lic.kind == "sineresi")
    metric = len(reading["metric_syllables"])
    arithmetic = f"{grammatical} sillabe grammaticali"
    if fusions:
        arithmetic += f" − {fusions} per sinalefe"
    if splits:
        arithmetic += f" + {splits} per dieresi"
    if merges:
        arithmetic += f" − {merges} per sineresi"
    cells = " ".join(f"{i + 1}:{c['text']}" for i, c in enumerate(scansion_cells(scansion)))
    steps.append(Passo("Sillabe metriche e sedi", (f"{arithmetic} = {metric} sillabe metriche", cells)))

    # ictus
    main, others = split_stresses(scansion.stresses, spec)
    lines = [f"Sillabe toniche in sede: {_ordinals(scansion.stresses)}",
             f"Ictus principali (sedi cardine del metro e ultimo ictus): {_ordinals(main)}"]
    if others:
        lines.append(f"Altre sillabe toniche: {_ordinals(others)}")
    contiguous = [(a, b) for a, b in zip(scansion.stresses, scansion.stresses[1:]) if b == a + 1]
    if contiguous:
        lines.append("Sillabe toniche contigue (urto d'accenti): " + ", ".join(f"{a}ª-{b}ª" for a, b in contiguous))
    steps.append(Passo("Ictus", tuple(lines)))

    # chiusura e conteggio metrico
    last = scansion.stresses[-1]
    after = metric - last
    count = last + 1
    lines = [f"L'ultimo ictus è in {last}ª sede e dopo {'resta 1 sillaba' if after == 1 else f'restano {after} sillabe'}: chiusura {chiusura_aggettivo(scansion.ending)}",
             f"Conteggio metrico: {last} + 1 = {count}"
             + (f" (misura {misura_del(nome_metro(count))})" if nome_metro(count) else " (misura non comune)")]
    if result.ok:
        lines.append(f"L'ultimo ictus cade in {max(spec.required_stress)}ª sede: il verso è un {spec.name}")
    else:
        lines.append(f"Per essere un {spec.name} l'ultimo ictus dovrebbe cadere in {max(spec.required_stress)}ª sede"
                     " in almeno una lettura possibile: non accade.")
    steps.append(Passo("Chiusura e conteggio metrico", tuple(lines)))

    if result.ok:
        sixth, fourth = 6 in scansion.stresses, 4 in scansion.stresses
        if sixth:
            lines = ["Ictus in 6ª sede: endecasillabo a maiore (6+5)"]
            if fourth:
                lines.append("Sono toniche sia la 4ª sia la 6ª: per il criterio adottato prevale la 6ª. "
                             "Alcuni manuali trattano questo schema a parte.")
        elif fourth:
            lines = ["Ictus in 4ª sede e non in 6ª: endecasillabo a minore (4+7)"]
        else:
            lines = ["Nessun ictus né in 4ª né in 6ª: endecasillabo non canonico"]
        steps.append(Passo("Tipo di endecasillabo", tuple(lines)))
        if scansion.alternatives:
            n_alt = len(scansion.alternatives)
            lines = ["Con lo stesso numero di licenze esiste un'altra lettura:" if n_alt == 1
                     else f"Con lo stesso numero di licenze esistono altre {n_alt} letture:"]
            for alt in scansion.alternatives:
                alt_main, _ = split_stresses(alt.stresses, spec)
                notes = [f"sinalefe {alt.words[i].text}‿{alt.words[i + 1].text}" for i in alt.reading["elisions"]]
                notes += [f"dialefe {alt.words[i].text}/{alt.words[i + 1].text}" for i in alt.reading["dialefi"]]
                lines.append(f"ictus principali {_ordinals(alt_main)} ({'; '.join(notes) or 'senza licenze'})"
                             + (" – stesse sedi toniche" if alt.stresses == scansion.stresses else " – sedi toniche diverse"))
            steps.append(Passo("Altre letture", tuple(lines)))
    return steps


def render_steps(steps: list[Passo], style, width: int = 80) -> list[str]:
    """I passi come righe di testo per il terminale (titoli in grassetto, righe a capo con rientro)."""
    import textwrap
    if not steps:
        return []
    lines = ["", style.bold("Come ho ragionato")]
    for number, step in enumerate(steps, 1):
        lines.append(style.bold(f"{number}. {step.titolo}"))
        for text in step.righe:
            lines += [style.dim(line) for line in textwrap.wrap(
                text, max(width - 12, 30), initial_indent="    ", subsequent_indent="      ")]
    return lines
