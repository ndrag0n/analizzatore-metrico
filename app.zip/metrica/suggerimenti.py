"""Suggerimenti per un verso non riconosciuto: accenti o iati diversi che lo renderebbero un endecasillabo."""
from __future__ import annotations

from .parole import _is_atonic, analyze_words
from .scansione import ENDECASILLABO, MeterSpec, Scansion, scan_verse
from .sillabe import _VOWELS
from .testo import _ACCENTED_VOWELS, extract_words

_GRAVE = {"a": "à", "e": "è", "i": "ì", "o": "ò", "u": "ù"}
_ORDINALS_FROM_END = {0: "sull'ultima sillaba", 1: "sulla penultima", 2: "sulla terzultima", 3: "sulla quartultima"}
MAX_SUGGESTIONS = 3
MAX_WORDS = 14                    # oltre, il verso è troppo lungo perché valga la pena provare


def _variants(token: str):
    """Le forme della parola con un accento scritto su ciascuna vocale (una alla volta)."""
    for k, letter in enumerate(token):
        if letter in "aeiou" and not (letter == "u" and k > 0 and token[k - 1] == "q"):
            yield token[:k] + _GRAVE[letter] + token[k + 1:]


def _reason(default_word, new_word) -> str:
    """Come cambia la parola: iato (più sillabe) oppure accento su un'altra sillaba."""
    if len(new_word.syllables) > len(default_word.syllables):
        return "iato " + "-".join(new_word.syllables)
    from_end = len(new_word.syllables) - 1 - (new_word.stress_idx or 0)
    return "accento " + _ORDINALS_FROM_END.get(from_end, "su un'altra sillaba")


def suggest_variants(
    line: str,
    exceptions: dict[str, str] | None = None,
    spec: MeterSpec = ENDECASILLABO,
    max_licenses: int = 2,
    limit: int = MAX_SUGGESTIONS,
) -> list[str]:
    """
    Per un verso che non rispetta `spec`, prova a cambiare l'accento (o a forzare un iato) di una
    parola alla volta e restituisce le frasi che descrivono le modifiche che lo rendono valido,
    dalla più alla meno naturale (lettura meno forzata, tipo canonico). Si provano solo le ipotesi
    plausibili: un iato (paùra, abbùia) o l'accento su un'altra sillaba di una parola di almeno tre
    sillabe (àncora/ancòra). Sono solo ipotesi: l'accento giusto lo decide chi scrive.
    """
    tokens = extract_words(line)
    if not tokens or len(tokens) > MAX_WORDS:
        return []
    found: list[tuple[tuple, str]] = []
    for i, token in enumerate(tokens):
        if any(ch in _ACCENTED_VOWELS for ch in token):
            continue                                   # già accentata dall'utente
        if sum(ch in _VOWELS for ch in token) < 2 or _is_atonic(token):
            continue                                   # un monosillabo o una parola atona non ha dove spostare l'accento
        default = analyze_words(" ".join(tokens), exceptions)
        by_text = {w.text: w for w in default}
        default_word = by_text.get(token)
        if default_word is None or default_word.stress_source in ("regola", "lessico"):
            continue                                   # accento già noto: non è un'ipotesi da discutere
        for variant in _variants(token):
            candidate = list(tokens)
            candidate[i] = variant
            words = analyze_words(" ".join(candidate), exceptions)
            new_word = next((w for w in words if w.text == variant), None)
            if new_word is None or new_word.syllables == default_word.syllables and new_word.stress_idx == default_word.stress_idx:
                continue
            hiatus = len(new_word.syllables) > len(default_word.syllables)
            moved_back = len(default_word.syllables) >= 3 and new_word.stress_idx != len(new_word.syllables) - 1
            if not (hiatus or moved_back):
                continue                               # es. «come» letta «còme»: non è italiano plausibile
            scansion = scan_verse(words, spec, max_licenses)
            if scansion is None:
                continue
            reason = _reason(default_word, new_word)
            key = (scansion.penalty, scansion.kind not in (None, *[k for k, _ in spec.kinds]),
                   reason.startswith("accento sull'ultima"), i)
            found.append((key, f"«{token}» letta «{variant}» ({reason}): {_outcome(scansion)}"))
    found.sort(key=lambda item: item[0])
    seen, result = set(), []
    for _, text in found:
        if text not in seen:
            seen.add(text)
            result.append(text)
    return result[:limit]


def _outcome(scansion: Scansion) -> str:
    kind = f" {scansion.kind}" if scansion.kind else ""
    return f"il verso diventa un {scansion.meter}{kind} {scansion.ending}"


def suggest_licenses(words, spec: MeterSpec = ENDECASILLABO) -> str | None:
    """Se il verso è escluso solo perché dieresi e sineresi sono vietate, dice quale lettura lo salverebbe."""
    scansion = scan_verse(words, spec, 2)
    if scansion is None or not scansion.licenses:
        return None
    what = " e ".join(f"{lic.kind} in «{lic.text}»" for lic in scansion.licenses)
    return f"ammettendo {what} il verso torna: {_outcome(scansion)}"
