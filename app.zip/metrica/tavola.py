"""Aspetto dell'output: colori opzionali e schema a colonne del verso, con le sedi numerate."""
from __future__ import annotations

import textwrap

from .poesia import VerseResult, summarize
from .accenti import _stressed_vowel_index
from .presentazione import describe_scansion
from .scansione import ENDECASILLABO, MeterSpec, Scansion, metric_length, split_stresses
from .sillabe import _find_nuclei
from .testo import _ACCENTED_VOWELS, _GRAVE


class Style:
    """Colora il testo con i codici ANSI; con color=False restituisce il testo com'è."""

    def __init__(self, color: bool = False):
        self.color = color

    def _paint(self, code: str, text: str) -> str:
        return f"\033[{code}m{text}\033[0m" if self.color and text.strip() else text

    def bold(self, text: str) -> str:
        return self._paint("1", text)

    def dim(self, text: str) -> str:
        return self._paint("2", text)

    def key_place(self, text: str) -> str:
        return self._paint("1;34", text)     # la sede obbligatoria (la 10ª)

    def sub_place(self, text: str) -> str:
        return self._paint("1;35", text)     # le sedi dei tipi canonici (4ª e 6ª)

    def accent(self, text: str) -> str:
        return self._paint("1;36", text)     # sillabe e segni degli ictus

    def good(self, text: str) -> str:
        return self._paint("32", text)

    def bad(self, text: str) -> str:
        return self._paint("31", text)

    def warn(self, text: str) -> str:
        return self._paint("33", text)


def _with_accent(syllable: str) -> str:
    """Scrive l'accento grafico sulla vocale tonica della sillaba (se non c'è già)."""
    if any(ch in _ACCENTED_VOWELS for ch in syllable):
        return syllable
    nuclei = _find_nuclei(syllable.lower())
    if not nuclei:
        return syllable
    i = _stressed_vowel_index(syllable.lower(), *nuclei[0])
    return syllable[:i] + _GRAVE.get(syllable[i].lower(), syllable[i]) + syllable[i + 1:]


def scansion_cells(scansion: Scansion) -> list[dict]:
    """
    Le sedi del verso: per ciascuna il testo (con l'accento grafico sulla vocale tonica e ‿ dove
    c'è una sinalefe) e se porta l'ictus. Si ricostruiscono dalle parole perché in una sinalefe
    bisogna sapere quale delle due sillabe fuse porta l'ictus.
    """
    fused = set(scansion.reading["elisions"])
    cells: list[list[tuple[str, bool]]] = []
    for w, word in enumerate(scansion.words):
        for j, syllable in enumerate(word.syllables):
            stressed = word.stress_idx == j
            part = (_with_accent(syllable) if stressed else syllable, stressed)
            if j == 0 and (w - 1) in fused:
                cells[-1].append(part)
            else:
                cells.append([part])
    return [
        {"text": "‿".join(text for text, _ in parts), "stressed": any(flag for _, flag in parts)}
        for parts in cells
    ]


def place_roles(spec: MeterSpec = ENDECASILLABO) -> dict[int, str]:
    """Le sedi da tenere d'occhio: 'required' (l'ultimo ictus obbligatorio) e 'kind' (4ª e 6ª)."""
    roles = {place: "kind" for _, places in spec.kinds for place in places}
    roles.update({place: "required" for place in spec.required_stress})
    return roles


def _grid(scansion: Scansion, style: Style, room: int) -> list[str]:
    """Le tre righe (sedi, sillabe, segni) del verso, andando a capo se superano `room` colonne."""
    cells = [(c["text"], c["stressed"]) for c in scansion_cells(scansion)]
    roles = place_roles()
    widths = [max(len(text), len(str(i + 1))) for i, (text, _) in enumerate(cells)]
    rows: list[str] = []
    start = 0
    while start < len(cells):
        end, used = start, 0
        while end < len(cells) and (end == start or used + widths[end] + 2 <= room):
            used += widths[end] + 2
            end += 1
        numbers, texts, marks = [], [], []
        for i in range(start, end):
            text, stressed = cells[i]
            paint = {"required": style.key_place, "kind": style.sub_place}.get(roles.get(i + 1), style.dim)
            numbers.append(paint(str(i + 1).center(widths[i])))
            texts.append(style.accent(text.center(widths[i])) if stressed else text.center(widths[i]))
            marks.append(style.accent("▲".center(widths[i])) if stressed else " " * widths[i])
        rows += ["  ".join(numbers).rstrip(), "  ".join(texts).rstrip(), "  ".join(marks).rstrip()]
        start = end
    return rows


def scansion_notes(scansion: Scansion) -> list[str]:
    """Le licenze della lettura: sinalefi, dialefi, dieresi e sineresi."""
    notes = []
    for index in scansion.reading["elisions"]:
        a, b = scansion.words[index], scansion.words[index + 1]
        notes.append(f"sinalefe {a.text}‿{b.text}")
    for index in scansion.reading["dialefi"]:
        a, b = scansion.words[index], scansion.words[index + 1]
        notes.append(f"dialefe {a.text}/{b.text}")
    for lic in scansion.licenses:
        notes.append(f"{lic.kind} in {lic.text}" + _license_remark(lic))
    return notes


def _license_remark(lic) -> str:
    """Quanto è forzata una licenza, dal suo peso: avvisa senza vietare."""
    if lic.kind != "dieresi":
        return ""
    if lic.weight >= 3.0:
        return " (forzata: contraria all'uso normale)"
    if lic.weight >= 2.0:
        return " (d'eccezione: Dante sì, Petrarca no)"
    return ""


def syllable_count_text(scansion: Scansion) -> str:
    """
    Il numero di sillabe: quelle che si vedono nello schema e, se il verso è tronco o sdrucciolo,
    anche il conteggio metrico (fino all'ultimo ictus più una): «10 sillabe (11 per la metrica)».
    """
    actual = len(scansion.reading["metric_syllables"])
    metric = metric_length(scansion.reading)
    text = f"{actual} sillabe" if actual != 1 else "1 sillaba"
    return text if metric == actual else f"{text} ({metric} per la metrica)"


def stress_text(scansion: Scansion) -> str:
    """«ictus 6ª 10ª · altre toniche 2ª 8ª»: gli ictus principali e le altre sillabe toniche."""
    main, others = split_stresses(scansion.stresses)
    text = "ictus " + " ".join(f"{p}ª" for p in main)
    return text + (" · altre toniche " + " ".join(f"{p}ª" for p in others) if others else "")


def _wrap(text: str, room: int) -> list[str]:
    """Va a capo con rientro di due spazi, così il simbolo ✔/✘/⚠ resta isolato."""
    return textwrap.wrap(text, max(room, 20), subsequent_indent="  ") or [""]


def _verse_block(result: VerseResult, style: Style, gutter: int, width: int, full_sentence: bool,
                 extra: list[str] | None = None) -> list[str]:
    margin = style.dim(" " * gutter + " │ ")
    first = style.dim(str(result.number).rjust(gutter) + " │ ")
    room = width - gutter - 3
    body: list[str] = []
    if result.error:
        body = [style.warn(line) for line in _wrap("⚠ riga non analizzabile: " + result.error, room)] + [style.dim(result.text)]
    elif result.ok:
        scansion = result.scansion
        body = _grid(scansion, style, max(room, 20))
        if full_sentence:
            body += [style.good(line) for line in _wrap("✔ " + describe_scansion(scansion), room)]
            body.append(style.dim("  " + syllable_count_text(scansion)))
        else:
            kind = f" {scansion.kind}" if scansion.kind else ""
            body.append(style.good(f"✔ {scansion.meter}{kind} · {scansion.ending}")
                        + style.dim(f" · {syllable_count_text(scansion)} · {stress_text(scansion)}"))
            notes = scansion_notes(scansion)
            if scansion.ambiguous:
                notes.append("altre letture possibili con ictus diversi")
            if notes:
                body.append(style.dim("  " + " · ".join(notes)))
    else:
        attempt = result.attempt
        if attempt:
            body = _grid(attempt, style, max(room, 20))
            body.append(style.bad("✘ non riconosciuto") + style.dim(f" · {syllable_count_text(attempt)} · {stress_text(attempt)}"))
        else:
            body = [style.dim(" | ".join("-".join(w.syllables) for w in result.words))]
        body += [style.bad(line) for line in _wrap("✘ " + (result.failure or "verso non riconosciuto"), room)]
        for hint in result.suggestions:
            body += [style.dim(line) for line in _wrap("💡 Prova: " + hint, room)]
    body += extra or []
    return [(first if i == 0 else margin) + line for i, line in enumerate(body)]


def render_poem(results: list[VerseResult], style: Style | None = None, width: int = 80, annotate=None) -> str:
    """
    Disegna l'analisi di uno o più versi: per ciascuno le sedi numerate, le sillabe (maiuscole
    e col segno ▲ quelle in ictus), il tipo di verso e le licenze usate, poi un riepilogo.
    `annotate(result)` può restituire righe da aggiungere sotto ogni verso (la spiegazione).
    """
    style = style or Style(False)
    verses = [r for r in results if not r.is_break]
    gutter = len(str(max((r.number for r in verses), default=1)))
    lines: list[str] = []
    for result in results:
        if result.is_break:
            lines.append("")
        else:
            extra = annotate(result) if annotate else None
            lines += _verse_block(result, style, gutter, width, full_sentence=len(verses) == 1, extra=extra)
    if len(verses) > 1:
        rule = style.dim("─" * min(width, 72))
        lines += ["", rule, style.bold("Riepilogo: ") + summarize(results), rule]
    return "\n".join(lines)
