"""Presentazione del risultato: schema grafico e frase descrittiva."""
from __future__ import annotations

from .parole import Word
from .scansione import (
    ENDECASILLABO, MeterSpec, Scansion, _candidate_readings, _last_stress_place, closest_scansion,
    metric_length, split_stresses,
)
from .terminologia import chiusura_aggettivo, misura_del, nome_metro


# ---------------------------------------------------------------------------
# Presentazione del risultato
# ---------------------------------------------------------------------------

def _ordinal(number: int) -> str:
    return f"{number}ª"


def render_scansion(scansion: Scansion) -> str:
    """
    Disegna il verso in colonne: numero della sede, sillabe metriche (con la sinalefe indicata
    da ‿) e un segno ▲ sotto le sillabe in ictus.
    """
    syllables = [s.replace("_", "‿") for s in scansion.reading["metric_syllables"]]
    stressed = {place - 1 for place in scansion.stresses}
    widths = [max(len(s), len(str(i + 1)), 1) for i, s in enumerate(syllables)]
    numbers = " ".join(str(i + 1).ljust(w) for i, w in enumerate(widths))
    cells = " ".join(
        (s.upper() if i in stressed else s).ljust(w) for i, (s, w) in enumerate(zip(syllables, widths))
    )
    marks = " ".join(("▲" if i in stressed else " ").ljust(w) for i, w in enumerate(widths))
    return "\n".join(line.rstrip() for line in (numbers, cells, marks))


def _join_italian(items: list[str]) -> str:
    return items[0] if len(items) == 1 else ", ".join(items[:-1]) + " e " + items[-1]


def describe_scansion(scansion: Scansion) -> str:
    """Una frase che dice che verso è, con le sedi dell'ictus, la chiusura e le licenze usate."""
    main, others = split_stresses(scansion.stresses)
    kind = f" {scansion.kind}" if scansion.kind else ""
    sentence = (f"È un {scansion.meter}{kind} con chiusura {chiusura_aggettivo(scansion.ending)}, "
                f"con ictus principali nelle sedi {_join_italian([_ordinal(p) for p in main])}")
    if others:
        sentence += f" e altre sillabe toniche nelle sedi {_join_italian([_ordinal(p) for p in others])}"
    if scansion.kind == "non canonico":
        sentence += " (manca l'ictus di 4ª o di 6ª)"
    notes = []
    for index in scansion.reading["elisions"]:
        pair = scansion.words[index], scansion.words[index + 1]
        notes.append(f"sinalefe tra «{pair[0].text}» e «{pair[1].text}»")
    for index in scansion.reading["dialefi"]:
        pair = scansion.words[index], scansion.words[index + 1]
        notes.append(f"dialefe tra «{pair[0].text}» e «{pair[1].text}»")
    for license_ in scansion.licenses:
        notes.append(f"{license_.kind} in «{license_.text}»")
    if notes:
        sentence += "; " + _join_italian(notes)
    if scansion.ambiguous:
        sentence += ". Ci sono altre letture possibili con ictus diversi"
    return sentence + "."


def describe_failure(words: list[Word], spec: MeterSpec = ENDECASILLABO, max_licenses: int = 2) -> str:
    """Spiega perché nessuna lettura rispetta `spec`: dove cade l'ultimo ictus."""
    last_places = sorted({
        place for _, _, reading in _candidate_readings(words, max_licenses)
        if (place := _last_stress_place(reading))
    })
    if not last_places:
        return f"Non è un {spec.name}: nel verso non c'è nessuna sillaba tonica."
    wanted = _ordinal(max(spec.required_stress))
    if len(last_places) > 3:
        found = f"tra la {_ordinal(last_places[0])} e la {_ordinal(last_places[-1])}"
    else:
        found = "sulla " + _join_italian([_ordinal(p) for p in last_places])
    message = (f"Non è un {spec.name}: l'ultimo ictus dovrebbe cadere sulla {wanted} sede, ma nelle "
               f"letture possibili (anche con dieresi e sineresi) cade {found}.")
    closest = closest_scansion(words, spec, max_licenses)
    length = metric_length(closest.reading) if closest else None
    if nome_metro(length) and nome_metro(length) != spec.name:
        message += f" Nella lettura più vicina ha {length} sillabe metriche, misura {misura_del(nome_metro(length))}."
    return message
