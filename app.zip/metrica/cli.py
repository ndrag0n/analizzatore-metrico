"""Interfaccia a riga di comando: argomenti, lettura di versi e poesie, stampa."""
from __future__ import annotations

import argparse
import os
import shutil
import sys
from pathlib import Path

from .lessico import _default_lexicon, load_exceptions
from .poesia import analyze_poem
from .spiegazione import explain_verse, render_steps
from .tavola import Style, render_poem
from .terminologia import glossario_testo

PROGRAM = "project.py"

MANUAL = """\
COSA FA
  Analizza versi italiani: mette gli accenti, divide in sillabe, prova sinalefi, dialefi,
  dieresi e sineresi, e dice se il verso è un endecasillabo (a maiore, a minore o non
  canonico; con chiusura tronca, piana, sdrucciola, bisdrucciola...). Per l'endecasillabo
  l'unica condizione è che l'ultimo ictus cada sulla 10ª sede.

COME DARE I VERSI
  Senza argomenti il programma è interattivo: incolla un verso o un'intera poesia e
  premi Invio su una riga vuota per analizzarla; scrivi «esci» (o Ctrl+D) per uscire.
  Le righe vuote dentro una poesia incollata separano le strofe. Un verso per riga.
  Con un file (anche «-» per lo standard input) analizza tutto il testo e termina:
    python project.py divina_commedia.txt
    cat poesia.txt | python project.py --no-color

ACCENTI GRAFICI (a carico tuo)
  Il programma indovina l'accento delle parole comuni, ma non quello di:
    - omografi:         àncora / ancòra, càpitano / capitàno
    - parole straniere: compùter
    - dieresi:          visïone (vi-si-o-ne), ruïna
  Scrivili con l'accento; un accento scritto ha sempre la precedenza. Gli accenti aperti e
  chiusi (è/é, ò/ó) sono equivalenti: conta solo la posizione.

COME LEGGERE L'OUTPUT
  Per ogni verso: le sedi numerate (la 10ª, obbligatoria, e la 4ª e 6ª sono colorate), le
  sillabe con l'accento scritto sulla vocale e il segno ▲ sotto quelle toniche, il numero di
  sillabe e il tipo di verso. ‿ indica una sinalefe. Sotto compaiono le licenze usate
  (sinalefe, dialefe, dieresi, sineresi). Con più versi, in fondo c'è un riepilogo.
  Il programma sceglie la lettura più naturale tra quelle che danno un endecasillabo: ogni
  licenza ha un peso, e per esempio una dialefe dopo vocale tonica pesa meno di una dieresi
  (come vuole la prassi di Dante e Petrarca), la dieresi di «pieno» più di quella di «mio».
  Una dieresi insolita è segnalata come «forzata» o «d'eccezione»: non è vietata, perché
  la poesia moderna è più libera. Se esistono altre letture con ictus diversi lo segnala.
  Le licenze interne alla parola (dieresi, sineresi) sono al massimo due per verso (--licenze);
  con --rigorosa (-r) sono vietate del tutto, utile per controllare di non averne usate.

MODALITÀ DIDATTICA E GLOSSARIO
  Con --spiega (-s) sotto ogni verso compare il ragionamento passo per passo: accento tonico di
  ogni parola e sua ragione, dittonghi e iati, incontri di vocali (sinalefe/dialefe), licenze,
  aritmetica delle sillabe, ictus, chiusura, conteggio metrico e tipo di verso.
  Con --glossario (-g) si stampa il glossario della terminologia (sede, ictus, sinalefe, chiusura...),
  compresi i criteri di classificazione adottati dove i manuali non concordano.
  Gli «ictus principali» sono le sedi cardine del metro (per l'endecasillabo 4ª, 6ª, 10ª e l'ultimo
  ictus); le altre sillabe toniche sono indicate a parte come «altre toniche».
  Il conteggio metrico (fino all'ultimo ictus più una sillaba) è indicato accanto alle sillabe reali.

FILE DI PAROLE (nella cartella del programma)
  exceptions.json, sdrucciole_extra.json, iati.json: parola -> parola accentata.
  Puoi aggiungere voci; non cancellarle. Con --eccezioni usi solo un tuo file.

CODICI DI USCITA
  0 tutto bene · 2 file non leggibile o argomenti errati
"""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog=PROGRAM,
        description="Analizzatore metrico dell'endecasillabo: ictus, sillabe, sinalefi e tipo di verso.",
        epilog=MANUAL,
        formatter_class=argparse.RawDescriptionHelpFormatter,
        add_help=False,
    )
    parser.add_argument("file", nargs="?", metavar="FILE",
                        help="file di testo con un verso per riga («-» = standard input); "
                             "senza FILE il programma è interattivo")
    parser.add_argument("-l", "--licenze", type=int, default=2, metavar="N",
                        help="massimo di dieresi/sineresi per verso (default 2; 0 le disattiva)")
    parser.add_argument("-r", "--rigorosa", action="store_true",
                        help="modalità rigorosa: nessuna dieresi né sineresi (equivale a -l 0)")
    parser.add_argument("-e", "--eccezioni", metavar="JSON",
                        help="usa solo questo lessico invece dei file predefiniti")
    parser.add_argument("--no-color", action="store_true",
                        help="niente colori (automatico se l'output non è un terminale o c'è NO_COLOR)")
    parser.add_argument("-s", "--spiega", action="store_true",
                        help="modalità didattica: sotto ogni verso il ragionamento passo per passo")
    parser.add_argument("-g", "--glossario", action="store_true",
                        help="stampa il glossario della terminologia metrica ed esce")
    parser.add_argument("-h", "--help", action="help", help="mostra questo manuale ed esce")
    return parser


def read_block(read_line=input, pending=None) -> str | None:
    """
    Legge dal terminale un verso o una poesia. Finisce con una riga vuota, a meno che subito
    dopo arrivi altro testo (una poesia incollata con righe vuote tra le strofe). Restituisce
    None se l'utente scrive «esci» o chiude l'input senza aver scritto nulla.
    """
    pending = pending or _input_pending
    lines: list[str] = []
    prompt = "Incolla un verso o una poesia (riga vuota per analizzare, «esci» per uscire):\n> "
    while True:
        try:
            line = read_line(prompt if not lines else "")
        except EOFError:
            return "\n".join(lines) if lines else None
        if not lines and line.strip().lower() in ("esci", "exit", "quit"):
            return None
        if not line.strip():
            if not lines:
                continue
            if not pending():
                return "\n".join(lines)
        lines.append(line)


def _input_pending() -> bool:
    """True se c'è già altro testo pronto da leggere (incolla): una riga vuota non conclude."""
    try:
        import select
        return bool(select.select([sys.stdin], [], [], 0.15)[0])
    except (ImportError, OSError, ValueError):
        return False


def _use_color(args: argparse.Namespace) -> bool:
    return not args.no_color and "NO_COLOR" not in os.environ and sys.stdout.isatty()


def _width() -> int:
    return min(shutil.get_terminal_size((80, 24)).columns, 110)


def _show(text: str, lexicon, args, style: Style) -> None:
    results = analyze_poem(text, lexicon, max_licenses=0 if args.rigorosa else args.licenze)
    annotate = (lambda result: render_steps(explain_verse(result), style, _width())) if args.spiega else None
    print(render_poem(results, style, _width(), annotate=annotate))


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.glossario:
        print(glossario_testo())
        return 0
    if args.licenze < 0:
        build_parser().error("--licenze deve essere 0 o più")
    lexicon = load_exceptions(args.eccezioni) if args.eccezioni else _default_lexicon()
    style = Style(_use_color(args))

    if args.file is not None or not sys.stdin.isatty():
        try:
            text = sys.stdin.read() if args.file in (None, "-") else Path(args.file).read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as error:
            print(f"Impossibile leggere {args.file}: {error}", file=sys.stderr)
            return 2
        _show(text, lexicon, args, style)
        return 0

    print(style.bold("ANALIZZATORE METRICO DELL'ENDECASILLABO"))
    print(style.dim("Incolla un verso o un'intera poesia. «python project.py -h» mostra il manuale.\n"))
    try:
        while (text := read_block()) is not None:
            print()
            _show(text, lexicon, args, style)
            print()
    except KeyboardInterrupt:
        print()
    print(style.dim("Arrivederci!"))
    return 0
